# encoding: utf-8
# module PyKDE4.soprano
# from /usr/lib/python2.7/dist-packages/PyKDE4/soprano.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class Soprano():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def Backend(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendFeature(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendFeatures(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendOption(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendOptions(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendSetting(self, *args, **kwargs):  # real signature unknown
        pass

    def BindingSet(self, *args, **kwargs):  # real signature unknown
        pass

    def Client(self, *args, **kwargs):  # real signature unknown
        pass

    def createModel(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def discoverBackendByFeatures(self, *args, **kwargs):
        pass

    def discoverBackendByName(self, *args, **kwargs):  # real signature unknown
        pass

    def Error(self, *args, **kwargs):  # real signature unknown
        pass

    def FilterModel(self, *args, **kwargs):  # real signature unknown
        pass

    def Graph(self, *args, **kwargs):  # real signature unknown
        pass

    def Inference(self, *args, **kwargs):  # real signature unknown
        pass

    def isOptionInSettings(self, *args, **kwargs):  # real signature unknown
        pass

    def LanguageTag(self, *args, **kwargs):  # real signature unknown
        pass

    def LiteralValue(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def mimeTypeToSerialization(self, *args, **kwargs):
        pass

    def Model(self, *args, **kwargs):  # real signature unknown
        pass

    def Node(self, *args, **kwargs):  # real signature unknown
        pass

    def NodeIterator(self, *args, **kwargs):  # real signature unknown
        pass

    def NRLModel(self, *args, **kwargs):  # real signature unknown
        pass

    def Parser(self, *args, **kwargs):  # real signature unknown
        pass

    def Plugin(self, *args, **kwargs):  # real signature unknown
        pass

    def PluginManager(self, *args, **kwargs):  # real signature unknown
        pass

    def qHash(self, *args, **kwargs):  # real signature unknown
        pass

    def Query(self, *args, **kwargs):  # real signature unknown
        pass

    def QueryResultIterator(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def QueryResultIteratorBackend(self, *args, **kwargs):
        pass

    def RdfSerialization(self, *args, **kwargs):  # real signature unknown
        pass

    def RdfSerializations(self, *args, **kwargs):  # real signature unknown
        pass

    def serializationMimeType(self, *args, **kwargs):  # real signature unknown
        pass

    def Serializer(self, *args, **kwargs):  # real signature unknown
        pass

    def Server(self, *args, **kwargs):  # real signature unknown
        pass

    def settingInSettings(self, *args, **kwargs):  # real signature unknown
        pass

    def setUsedBackend(self, *args, **kwargs):  # real signature unknown
        pass

    def Statement(self, *args, **kwargs):  # real signature unknown
        pass

    def StatementIterator(self, *args, **kwargs):  # real signature unknown
        pass

    def StorageModel(self, *args, **kwargs):  # real signature unknown
        pass

    def usedBackend(self, *args, **kwargs):  # real signature unknown
        pass

    def Util(self, *args, **kwargs):  # real signature unknown
        pass

    def valueInSettings(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def valueInSettingsWithDefault(self, *args, **kwargs):
        pass

    def Vocabulary(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    BackendFeatureAddStatement = 1
    BackendFeatureAll = 255
    BackendFeatureContext = 64
    BackendFeatureInference = 16
    BackendFeatureInferenceOptional = 32
    BackendFeatureListStatements = 4
    BackendFeatureNone = 0
    BackendFeatureQuery = 8
    BackendFeatureRemoveStatements = 2
    BackendFeatureStorageMemory = 128
    BackendFeatureUser = 4096
    BackendOptionEnableInference = 2
    BackendOptionHost = 8
    BackendOptionNone = 0
    BackendOptionPassword = 64
    BackendOptionPort = 16
    BackendOptionStorageDir = 4
    BackendOptionStorageMemory = 1
    BackendOptionUser = 4096
    BackendOptionUsername = 32
    SerializationN3 = 2
    SerializationNQuads = 32
    SerializationNTriples = 4
    SerializationRdfXml = 1
    SerializationTrig = 16
    SerializationTurtle = 8
    SerializationUnknown = 0
    SerializationUser = 0
