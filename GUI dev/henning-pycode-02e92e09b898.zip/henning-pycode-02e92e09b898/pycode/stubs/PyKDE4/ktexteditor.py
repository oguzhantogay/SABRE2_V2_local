# encoding: utf-8
# module PyKDE4.ktexteditor
# from /usr/lib/python2.7/dist-packages/PyKDE4/ktexteditor.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class KTextEditor():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def Attribute(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def CodeCompletionInterface(self, *args, **kwargs):
        pass

    def CodeCompletionModel(self, *args, **kwargs):  # real signature unknown
        pass

    def Command(self, *args, **kwargs):  # real signature unknown
        pass

    def CommandExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def CommandInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def ConfigInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def ConfigPage(self, *args, **kwargs):  # real signature unknown
        pass

    def ContainerInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def createPlugin(self, *args, **kwargs):  # real signature unknown
        pass

    def Cursor(self, *args, **kwargs):  # real signature unknown
        pass

    def Document(self, *args, **kwargs):  # real signature unknown
        pass

    def Editor(self, *args, **kwargs):  # real signature unknown
        pass

    def editor(self, *args, **kwargs):  # real signature unknown
        pass

    def EditorChooser(self, *args, **kwargs):  # real signature unknown
        pass

    def Factory(self, *args, **kwargs):  # real signature unknown
        pass

    def Mark(self, *args, **kwargs):  # real signature unknown
        pass

    def MarkInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def ModificationInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def Plugin(self, *args, **kwargs):  # real signature unknown
        pass

    def Range(self, *args, **kwargs):  # real signature unknown
        pass

    def Search(self, *args, **kwargs):  # real signature unknown
        pass

    def SearchInterface(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def SessionConfigInterface(self, *args, **kwargs):
        pass

    def SmartCursor(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartCursorNotifier(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartCursorWatcher(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartRange(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartRangeNotifier(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartRangeWatcher(self, *args, **kwargs):  # real signature unknown
        pass

    def TemplateInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def TextHintInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def VariableInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def View(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
