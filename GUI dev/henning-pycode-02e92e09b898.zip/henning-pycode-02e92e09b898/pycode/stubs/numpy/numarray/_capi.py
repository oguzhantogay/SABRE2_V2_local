# encoding: utf-8
# module numpy.numarray._capi
# from /usr/lib/pymodules/python2.7/numpy/numarray/_capi.so by generator 1.96
# no doc
# no imports

# Variables with simple values

__version__ = '0.9'

# no functions
# classes


class error(Exception):
    # no doc

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default


# variables with complex values

_C_API = None  # (!) real value is ''
