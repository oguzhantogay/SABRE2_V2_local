# encoding: utf-8
# module PyKDE4.kutils
# from /usr/lib/python2.7/dist-packages/PyKDE4/kutils.so by generator 1.96
# no doc

# imports
import PyKDE4.kdeui as __PyKDE4_kdeui
import PyQt4.QtCore as __PyQt4_QtCore
import PyQt4.QtGui as __PyQt4_QtGui


# no functions
# classes

class KCModuleInfo():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def comment(self, *args, **kwargs):  # real signature unknown
        pass

    def docPath(self, *args, **kwargs):  # real signature unknown
        pass

    def fileName(self, *args, **kwargs):  # real signature unknown
        pass

    def handle(self, *args, **kwargs):  # real signature unknown
        pass

    def icon(self, *args, **kwargs):  # real signature unknown
        pass

    def keywords(self, *args, **kwargs):  # real signature unknown
        pass

    def library(self, *args, **kwargs):  # real signature unknown
        pass

    def moduleName(self, *args, **kwargs):  # real signature unknown
        pass

    def service(self, *args, **kwargs):  # real signature unknown
        pass

    def weight(self, *args, **kwargs):  # real signature unknown
        pass

    def __eq__(self, y):  # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    def __le__(self, y):  # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object())  # default


class KCModuleLoader():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def ErrorReporting(self, *args, **kwargs):  # real signature unknown
        pass

    def loadModule(self, *args, **kwargs):  # real signature unknown
        pass

    def reportError(self, *args, **kwargs):  # real signature unknown
        pass

    def showLastLoaderError(self, *args, **kwargs):  # real signature unknown
        pass

    def unloadModule(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    Both = 3
    Dialog = 2
    Inline = 1
    None = 0


class KCModuleProxy(__PyQt4_QtGui.QWidget):
    # no doc

    def aboutData(self, *args, **kwargs):  # real signature unknown
        pass

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def buttons(self, *args, **kwargs):  # real signature unknown
        pass

    def changed(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childClosed(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def componentData(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dbusPath(self, *args, **kwargs):  # real signature unknown
        pass

    def dbusService(self, *args, **kwargs):  # real signature unknown
        pass

    def defaults(self, *args, **kwargs):  # real signature unknown
        pass

    def deleteClient(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def load(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def minimumSizeHint(self, *args, **kwargs):  # real signature unknown
        pass

    def moduleInfo(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def quickHelp(self, *args, **kwargs):  # real signature unknown
        pass

    def quickHelpChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def realModule(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def rootOnlyMessage(self, *args, **kwargs):  # real signature unknown
        pass

    def save(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def useRootOnlyMessage(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KCMultiDialog(__PyKDE4_kdeui.KPageDialog):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def addModule(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def clear(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def configCommitted(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def eventFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def pageWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setButtons(self, *args, **kwargs):  # real signature unknown
        pass

    def setPageWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def slotApplyClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def slotButtonClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def slotDefaultClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def slotHelpClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def slotOkClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def slotUser1Clicked(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateGeometry(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KEmoticons(__PyQt4_QtCore.QObject):
    # no doc

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def currentThemeName(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def installTheme(self, *args, **kwargs):  # real signature unknown
        pass

    def newTheme(self, *args, **kwargs):  # real signature unknown
        pass

    def parseMode(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setParseMode(self, *args, **kwargs):  # real signature unknown
        pass

    def setTheme(self, *args, **kwargs):  # real signature unknown
        pass

    def theme(self, *args, **kwargs):  # real signature unknown
        pass

    def themeList(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KEmoticonsProvider(__PyQt4_QtCore.QObject):
    # no doc

    def addEmoticon(self, *args, **kwargs):  # real signature unknown
        pass

    def addEmoticonIndex(self, *args, **kwargs):  # real signature unknown
        pass

    def AddEmoticonOption(self, *args, **kwargs):  # real signature unknown
        pass

    def addEmoticonsMap(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def clearEmoticonsMap(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def createNew(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def Emoticon(self, *args, **kwargs):  # real signature unknown
        pass

    def emoticonsMap(self, *args, **kwargs):  # real signature unknown
        pass

    def fileName(self, *args, **kwargs):  # real signature unknown
        pass

    def loadTheme(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def removeEmoticon(self, *args, **kwargs):  # real signature unknown
        pass

    def removeEmoticonIndex(self, *args, **kwargs):  # real signature unknown
        pass

    def removeEmoticonsMap(self, *args, **kwargs):  # real signature unknown
        pass

    def save(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setThemeName(self, *args, **kwargs):  # real signature unknown
        pass

    def themeName(self, *args, **kwargs):  # real signature unknown
        pass

    def themePath(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    Copy = 1
    DoNotCopy = 0


class KEmoticonsTheme():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def addEmoticon(self, *args, **kwargs):  # real signature unknown
        pass

    def createNew(self, *args, **kwargs):  # real signature unknown
        pass

    def emoticonsMap(self, *args, **kwargs):  # real signature unknown
        pass

    def fileName(self, *args, **kwargs):  # real signature unknown
        pass

    def isNull(self, *args, **kwargs):  # real signature unknown
        pass

    def loadTheme(self, *args, **kwargs):  # real signature unknown
        pass

    def parseEmoticons(self, *args, **kwargs):  # real signature unknown
        pass

    def ParseMode(self, *args, **kwargs):  # real signature unknown
        pass

    def ParseModeEnum(self, *args, **kwargs):  # real signature unknown
        pass

    def removeEmoticon(self, *args, **kwargs):  # real signature unknown
        pass

    def save(self, *args, **kwargs):  # real signature unknown
        pass

    def setThemeName(self, *args, **kwargs):  # real signature unknown
        pass

    def themeName(self, *args, **kwargs):  # real signature unknown
        pass

    def themePath(self, *args, **kwargs):  # real signature unknown
        pass

    def Token(self, *args, **kwargs):  # real signature unknown
        pass

    def tokenize(self, *args, **kwargs):  # real signature unknown
        pass

    def TokenType(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    DefaultParse = 0
    Image = 1
    RelaxedParse = 2
    SkipHTML = 4
    StrictParse = 1
    Text = 2
    Undefined = 0


class KIdleTime(__PyQt4_QtCore.QObject):
    # no doc

    def addIdleTimeout(self, *args, **kwargs):  # real signature unknown
        pass

    def catchNextResumeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def idleTime(self, *args, **kwargs):  # real signature unknown
        pass

    def idleTimeouts(self, *args, **kwargs):  # real signature unknown
        pass

    def instance(self, *args, **kwargs):  # real signature unknown
        pass

    def removeAllIdleTimeouts(self, *args, **kwargs):  # real signature unknown
        pass

    def removeIdleTimeout(self, *args, **kwargs):  # real signature unknown
        pass

    def resumingFromIdle(self, *args, **kwargs):  # real signature unknown
        pass

    def simulateUserActivity(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def stopCatchingResumeEvent(self, *args, **kwargs):
        pass

    def timeoutReached(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KPluginSelector(__PyQt4_QtGui.QWidget):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def addPlugins(self, *args, **kwargs):  # real signature unknown
        pass

    def changed(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def configCommitted(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def defaults(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def isDefault(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def load(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def PluginLoadMethod(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def save(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def updatePluginsState(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    IgnoreConfigFile = 1
    ReadConfigFile = 0


class KPrintPreview(__PyKDE4_kdeui.KDialog):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def eventFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def isAvailable(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def slotButtonClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateGeometry(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KSettings():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def Dialog(self, *args, **kwargs):  # real signature unknown
        pass

    def Dispatcher(self, *args, **kwargs):  # real signature unknown
        pass

    def PluginPage(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
