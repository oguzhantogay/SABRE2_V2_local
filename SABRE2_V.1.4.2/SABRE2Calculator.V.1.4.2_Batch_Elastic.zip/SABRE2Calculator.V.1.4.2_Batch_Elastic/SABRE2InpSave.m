function SABRE2InpSave(File,ptable_node,ptable_seg,pdesign_edit,punit_edit,AnalP)  
% Developed by Woo Yong Jeong.
% Date : 12/01/2012.
% ************************************************************************
% *****************    INPUT FILE GENERATOR           ********************
% ************************************************************************

   % get geometry table data
   G_getdata=get(ptable_node,'Data');
   [p,q]=size(G_getdata);
   % get material table data
   M_getdata=get(ptable_seg,'Data');
   [r,s]=size(M_getdata);

   % Define a file name of I/O 
   outfile =strcat(File);   % Output file name.
   out = fopen(outfile,'w');                       % Output file is opened.
   %--------------------------------------------------------------------------
   % POSTPROCESSOR
   %--------------------------------------------------------------------------
   %WRITING NODAL INFORMATION
   fprintf(out,'****************************************************\n');
   fprintf(out,'*                SABRE2Calculator                  *\n');
   fprintf(out,'****************************************************\n');
%    fprintf(out,'\n');
   fprintf(out,'** Design Axis\n');
   daxis=get(pdesign_edit,'Value');
   fprintf(out,'          %d',daxis);        
   fprintf(out,'\n');
   fprintf(out,'** Units\n');
   dunit=get(punit_edit,'Value');
   fprintf(out,'          %d',dunit);        
   fprintf(out,'\n');   
   fprintf(out,'*Define Joint & Essential Node Geometry, Loads and Boundary Conditions\n');
   fprintf(out,'** X Coordinates\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(1,i));
   end             
   fprintf(out,'\n');
   fprintf(out,'** bf1\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(2,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** tf1\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(3,i));
   end   
   fprintf(out,'\n');
   fprintf(out,'** bf2\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(4,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** tf2\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(5,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** dw\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(6,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** tw\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(7,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** Afillets\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(8,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** Px\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(9,i));
   end    
   fprintf(out,'\n');
   fprintf(out,'** Py\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(10,i));
   end         
   fprintf(out,'\n');
   fprintf(out,'** Mz\n');
   for i=1:q
           fprintf(out,'  %9.5f',G_getdata(11,i));
   end           
   fprintf(out,'\n');
   fprintf(out,'** Boundary Conditions\n');
   for i=1:q
           fprintf(out,'          %d',G_getdata(12,i));
   end 
   fprintf(out,'\n');
   fprintf(out,'** Load Height\n');
   for i=1:q
           fprintf(out,'          %d',G_getdata(13,i));
   end    
   fprintf(out,'\n');
   fprintf(out,'** Step\n'); 
   for i=1:q
           fprintf(out,'          %d',G_getdata(14,i));
   end           
   fprintf(out,'\n');
%    fprintf(out,'\n');
   fprintf(out,'* Subdivide Segment(s) and Assign Yield Stresses\n');
   fprintf(out,'** # of Elements\n');
   for i=1:s
           fprintf(out,'  %9.0f',M_getdata(1,i));
   end  
   fprintf(out,'\n');
   fprintf(out,'** Fyf1\n');
   for i=1:s
           fprintf(out,'  %9.2f',M_getdata(2,i));
   end    
   fprintf(out,'\n');
   fprintf(out,'** Fyw\n');
   for i=1:s
           fprintf(out,'  %9.2f',M_getdata(3,i));
   end   
   fprintf(out,'\n');
   fprintf(out,'** Fyf2\n');
   for i=1:s
           fprintf(out,'  %9.2f',M_getdata(4,i));
   end      
   fprintf(out,'\n');
   fprintf(out,'* Specify Analysis Parameters\n');
   fprintf(out,'** Use J = 0 for Slender Web Sections in EBA (Yes = 1, No = 0) \n');         
   for i=1:1
           fprintf(out,'       %d',AnalP(2,i));
   end     
   fprintf(out,'\n');
   fprintf(out,'** Use the AISC (2016) Provisions (Yes = 1, No = 0) \n');         
   for i=1:1
           fprintf(out,'       %d',AnalP(3,i));
   end     
   fprintf(out,'\n');
%    fprintf(out,'** Bracketing Algorithm (On/Off) \n');         
%    for i=1:1
%            fprintf(out,'       %d',AnalP(3,i));
%    end   
%    fprintf(out,'\n');
   fprintf(out,'** Use the DM SRF for GNA in INBA (Yes = 1, No = 0) \n');         
   for i=1:1
           fprintf(out,'       %d',AnalP(4,i));
   end   
   fprintf(out,'\n');
   fclose(out);
end % function end
