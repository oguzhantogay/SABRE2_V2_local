# encoding: utf-8
# module scipy.optimize._lbfgsb
# from /usr/lib/python2.7/dist-packages/scipy/optimize/_lbfgsb.so by
# generator 1.96
"""
This module '_lbfgsb' is auto-generated with f2py (version:1).
Functions:
  setulb(m,x,l,u,nbd,f,g,factr,pgtol,wa,iwa,task,iprint,csave,lsave,isave,dsave,n=len(x))
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

setulb = None  # (!) real value is ''
