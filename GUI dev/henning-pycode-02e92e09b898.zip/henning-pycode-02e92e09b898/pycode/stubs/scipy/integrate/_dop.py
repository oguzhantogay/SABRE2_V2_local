# encoding: utf-8
# module scipy.integrate._dop
# from /usr/lib/python2.7/dist-packages/scipy/integrate/_dop.so by
# generator 1.96
"""
This module '_dop' is auto-generated with f2py (version:1).
Functions:
  x,y,iwork,idid = dopri5(fcn,x,y,xend,rtol,atol,solout,work,iwork,fcn_extra_args=(),overwrite_y=0,solout_extra_args=())
  x,y,iwork,idid = dop853(fcn,x,y,xend,rtol,atol,solout,work,iwork,fcn_extra_args=(),overwrite_y=0,solout_extra_args=())
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

dop853 = None  # (!) real value is ''

dopri5 = None  # (!) real value is ''
