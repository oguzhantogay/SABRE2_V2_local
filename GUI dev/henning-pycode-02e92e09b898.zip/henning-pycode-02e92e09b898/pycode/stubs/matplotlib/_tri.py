# encoding: utf-8
# module matplotlib._tri
# from /usr/lib/pymodules/python2.7/matplotlib/_tri.so by generator 1.96
# no doc
# no imports

# functions


def Triangulation(*args, **kwargs):  # real signature unknown
    """ Create and return new C++ Triangulation object """
    pass


def TriContourGenerator(*args, **kwargs):  # real signature unknown
    """ Create and return new C++ TriContourGenerator object """
    pass


# no classes
