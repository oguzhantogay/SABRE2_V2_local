# encoding: utf-8
# module matplotlib._path
# from /usr/lib/pymodules/python2.7/matplotlib/_path.so by generator 1.96
""" Helper functions for paths """
# no imports

# functions

# real signature unknown; restored from __doc__


def affine_transform(vertices, transform):
    """ affine_transform(vertices, transform) """
    pass


# real signature unknown; restored from __doc__
def cleanup_path(path, trans, remove_nans, clip, snap, simplify, curves):
    """ cleanup_path(path, trans, remove_nans, clip, snap, simplify, curves) """
    pass


# real signature unknown; restored from __doc__
def clip_path_to_rect(path, bbox, inside):
    """ clip_path_to_rect(path, bbox, inside) """
    pass


# real signature unknown; restored from __doc__
def convert_path_to_polygons(path, trans, width, height):
    """ convert_path_to_polygons(path, trans, width, height) """
    pass


# real signature unknown; restored from __doc__
def count_bboxes_overlapping_bbox(bbox, bboxes):
    """ count_bboxes_overlapping_bbox(bbox, bboxes) """
    pass


# real signature unknown; restored from __doc__
def get_path_collection_extents(trans, paths, transforms, offsets, offsetTrans):
    """ get_path_collection_extents(trans, paths, transforms, offsets, offsetTrans) """
    pass


# real signature unknown; restored from __doc__
def get_path_extents(path, trans):
    """ get_path_extents(path, trans) """
    pass


# real signature unknown; restored from __doc__
def path_intersects_path(p1, p2):
    """ path_intersects_path(p1, p2) """
    pass


# real signature unknown; restored from __doc__
def path_in_path(a, atrans, b, btrans):
    """ path_in_path(a, atrans, b, btrans) """
    pass


# real signature unknown; restored from __doc__
def point_in_path(x, y, path, trans):
    """ point_in_path(x, y, path, trans) """
    pass


# real signature unknown; restored from __doc__
def point_in_path_collection(x, y, r, trans, paths, transforms, offsets, offsetTrans, filled):
    """ point_in_path_collection(x, y, r, trans, paths, transforms, offsets, offsetTrans, filled) """
    pass


# real signature unknown; restored from __doc__
def point_on_path(x, y, r, path, trans):
    """ point_on_path(x, y, r, path, trans) """
    pass


# real signature unknown; restored from __doc__
def update_path_extents(path, trans, bbox, minpos):
    """ update_path_extents(path, trans, bbox, minpos) """
    pass


# no classes
