#!/usr/bin/env python
# module: 'itertools'


class chain:
    pass


class count:
    pass


class cycle:
    pass


class dropwhile:
    pass


class groupby:
    pass


class ifilter:
    pass


class ifilterfalse:
    pass


class imap:
    pass


class islice:
    pass


class izip:
    pass


class repeat:
    pass


class starmap:
    pass


class takewhile:
    pass


def tee(*x):
    return
