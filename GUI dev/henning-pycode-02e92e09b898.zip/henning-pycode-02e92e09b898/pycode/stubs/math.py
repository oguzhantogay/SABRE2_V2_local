#!/usr/bin/env python
# module: 'math'

e = 0.0
pi = 0.0


def acos(x):
    return


def asin(x):
    return


def atan(x):
    return


def atan2(x, y):
    return


def ceil(x):
    return


def cos(x):
    return


def cosh(x):
    return


def degrees(x):
    return


def exp(x):
    return


def fabs(x):
    return


def floor(x):
    return


def fmod(x, y):
    return


def frexp(x):
    return


def hypot(x, y):
    return


def ldexp(x, i):
    return


def log(x, base=0):
    return


def log10(x):
    return


def modf(x):
    return


def pow(x, y):
    return


def radians(x):
    return


def sin(x):
    return


def sinh(x):
    return


def sqrt(x):
    return


def tan(x):
    return


def tanh(x):
    return
