# encoding: utf-8
# module numpy.core.multiarray_tests
# from /usr/lib/pymodules/python2.7/numpy/core/multiarray_tests.so by generator 1.96
# no doc
# no imports

# functions


def test_neighborhood_iterator(*args, **kwargs):  # real signature unknown
    pass


def test_neighborhood_iterator_oob(*args, **kwargs):  # real signature unknown
    pass


# no classes
