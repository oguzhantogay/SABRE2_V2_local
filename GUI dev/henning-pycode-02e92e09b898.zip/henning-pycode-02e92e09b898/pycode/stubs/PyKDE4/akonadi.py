# encoding: utf-8
# module PyKDE4.akonadi
# from /usr/lib/python2.7/dist-packages/PyKDE4/akonadi.so by generator 1.96
# no doc
# no imports

# functions


def qHash(*args, **kwargs):  # real signature unknown
    pass


# classes

class Akonadi():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def AddressAttribute(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentActionManager(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentBase(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentFactoryBase(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentFilterProxyModel(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentInstance(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def AgentInstanceCreateJob(self, *args, **kwargs):
        pass

    def AgentInstanceModel(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentInstanceWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentManager(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentSearchInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentType(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentTypeDialog(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentTypeModel(self, *args, **kwargs):  # real signature unknown
        pass

    def AgentTypeWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def Attribute(self, *args, **kwargs):  # real signature unknown
        pass

    def AttributeFactory(self, *args, **kwargs):  # real signature unknown
        pass

    def CachePolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def ChangeRecorder(self, *args, **kwargs):  # real signature unknown
        pass

    def Collection(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def CollectionAttributesSynchronizationJob(self, *args, **kwargs):
        pass

    def CollectionComboBox(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionCopyJob(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionCreateJob(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionDeleteJob(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionDialog(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionFetchJob(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionFetchScope(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def CollectionFilterProxyModel(self, *args, **kwargs):
        pass

    def CollectionModel(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionModifyJob(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionMoveJob(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def CollectionPropertiesDialog(self, *args, **kwargs):
        pass

    # real signature unknown
    def CollectionPropertiesPage(self, *args, **kwargs):
        pass

    # real signature unknown
    def CollectionPropertiesPageFactory(self, *args, **kwargs):
        pass

    # real signature unknown
    def CollectionQuotaAttribute(self, *args, **kwargs):
        pass

    def CollectionRequester(self, *args, **kwargs):  # real signature unknown
        pass

    def CollectionStatistics(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def CollectionStatisticsDelegate(self, *args, **kwargs):
        pass

    # real signature unknown
    def CollectionStatisticsJob(self, *args, **kwargs):
        pass

    # real signature unknown
    def CollectionStatisticsModel(self, *args, **kwargs):
        pass

    def CollectionView(self, *args, **kwargs):  # real signature unknown
        pass

    def Control(self, *args, **kwargs):  # real signature unknown
        pass

    def Entity(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def EntityDisplayAttribute(self, *args, **kwargs):
        pass

    def EntityHiddenAttribute(self, *args, **kwargs):  # real signature unknown
        pass

    def EntityListView(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def EntityMimeTypeFilterModel(self, *args, **kwargs):
        pass

    def EntityOrderProxyModel(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def EntityRightsFilterModel(self, *args, **kwargs):
        pass

    def EntityTreeModel(self, *args, **kwargs):  # real signature unknown
        pass

    def EntityTreeView(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def EntityTreeViewStateSaver(self, *args, **kwargs):
        pass

    def ETMViewStateSaver(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def FavoriteCollectionsModel(self, *args, **kwargs):
        pass

    def IndexPolicyAttribute(self, *args, **kwargs):  # real signature unknown
        pass

    def Item(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemCopyJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemCreateJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemDeleteJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemFetchJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemFetchScope(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemModel(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemModifyJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemMonitor(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemMoveJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemSearchJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemSerializerPlugin(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def ItemSerializerPluginV2(self, *args, **kwargs):
        pass

    def ItemSync(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemView(self, *args, **kwargs):  # real signature unknown
        pass

    def Job(self, *args, **kwargs):  # real signature unknown
        pass

    def LinkJob(self, *args, **kwargs):  # real signature unknown
        pass

    def MessageFlags(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def MessageFolderAttribute(self, *args, **kwargs):
        pass

    def MessageModel(self, *args, **kwargs):  # real signature unknown
        pass

    def MessagePart(self, *args, **kwargs):  # real signature unknown
        pass

    def MessageStatus(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def MessageThreaderProxyModel(self, *args, **kwargs):
        pass

    # real signature unknown
    def MessageThreadingAttribute(self, *args, **kwargs):
        pass

    def MimeTypeChecker(self, *args, **kwargs):  # real signature unknown
        pass

    def Monitor(self, *args, **kwargs):  # real signature unknown
        pass

    def PartFetcher(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def PersistentSearchAttribute(self, *args, **kwargs):
        pass

    def PreprocessorBase(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def RecursiveCollectionFilterProxyModel(self, *args, **kwargs):
        pass

    def RecursiveItemFetchJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ResourceBase(self, *args, **kwargs):  # real signature unknown
        pass

    def ResourceBaseSettings(self, *args, **kwargs):  # real signature unknown
        pass

    def ResourceSettings(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def ResourceSynchronizationJob(self, *args, **kwargs):
        pass

    def SearchCreateJob(self, *args, **kwargs):  # real signature unknown
        pass

    def SelectionProxyModel(self, *args, **kwargs):  # real signature unknown
        pass

    def ServerManager(self, *args, **kwargs):  # real signature unknown
        pass

    def Session(self, *args, **kwargs):  # real signature unknown
        pass

    def SpecialCollections(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def SpecialCollectionsRequestJob(self, *args, **kwargs):
        pass

    # real signature unknown
    def SpecialMailCollections(self, *args, **kwargs):
        pass

    # real signature unknown
    def SpecialMailCollectionsRequestJob(self, *args, **kwargs):
        pass

    def StandardActionManager(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def StandardMailActionManager(self, *args, **kwargs):
        pass

    def StatisticsProxyModel(self, *args, **kwargs):  # real signature unknown
        pass

    def TransactionBeginJob(self, *args, **kwargs):  # real signature unknown
        pass

    def TransactionCommitJob(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def TransactionRollbackJob(self, *args, **kwargs):
        pass

    def TransactionSequence(self, *args, **kwargs):  # real signature unknown
        pass

    def TransportResourceBase(self, *args, **kwargs):  # real signature unknown
        pass

    def UnlinkJob(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
