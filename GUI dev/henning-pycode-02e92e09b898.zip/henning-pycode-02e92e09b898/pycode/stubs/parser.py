#!/usr/bin/env python
# module: 'parser'


class ASTType:
    pass


class ParserError:
    pass


class STType:
    pass


def _pickler(*x):
    return


def ast2list(*x):
    return


def ast2tuple(*x):
    return


def compileast(*x):
    return


def compilest(*x):
    return


def expr(*x):
    return


def isexpr(*x):
    return


def issuite(*x):
    return


def sequence2ast(*x):
    return


def sequence2st(*x):
    return


def st2list(*x):
    return


def st2tuple(*x):
    return


def suite(*x):
    return


def tuple2ast(*x):
    return


def tuple2st(*x):
    return
