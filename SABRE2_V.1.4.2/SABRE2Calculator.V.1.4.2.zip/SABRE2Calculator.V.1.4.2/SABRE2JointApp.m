function [JNodevalue]=SABRE2JointApp(JNodevalue,ptable_node,pt_title_name)
% Developed by Woo Yong Jeong.
% Date : 12/01/2012.
% ************************************************************************
% *****************       Add Joint Node              ********************
% ************************************************************************ 
% Get Joint number : pdn_type_name (Joint number)
njnode = 1;
G_getdata=get(ptable_node,'Data');
% ************************************************************************
% ********     JNodevalue=[njnode jcoordx jcoordy jcoordz]          ******
% ************************************************************************
% Empty; NaN; Not positive, 
if isempty(G_getdata(1,1)) || isempty(G_getdata(1,end)) ...
      || isnan(G_getdata(1,1)) || isnan(G_getdata(1,end)) 
   set(pt_title_name,'String','Please, define X-coordinates')
   set(pt_title_name,'Visible','on') 
else
   length = abs( G_getdata(1,end)-G_getdata(1,1) );
   if length <= 0
      set(pt_title_name,'String','Please, define proper X-coordinates')
      set(pt_title_name,'Visible','on')       
   else
      set(pt_title_name,'Visible','off') % Hide BACKGROUNG TEXT  
      % Joint 1
      JNodevalue(njnode,1)=njnode;
      JNodevalue(njnode,2)=G_getdata(1,1);
      JNodevalue(njnode,3)=0;
      JNodevalue(njnode,4)=0;   
      % Joint 2
      JNodevalue(njnode+1,1)=njnode+1;
      JNodevalue(njnode+1,2)=G_getdata(1,end);
      JNodevalue(njnode+1,3)=0;
      JNodevalue(njnode+1,4)=0;     
   end
end % if end






