#!/usr/bin/env python
# module: 'readline'


def add_history(*x):
    return


def clear_history(*x):
    return


def get_begidx(*x):
    return


def get_completer(*x):
    return


def get_completer_delims(*x):
    return


def get_current_history_length(*x):
    return


def get_endidx(*x):
    return


def get_history_item(*x):
    return


def get_history_length(*x):
    return


def get_line_buffer(*x):
    return


def insert_text(*x):
    return


def parse_and_bind(*x):
    return


def read_history_file(*x):
    return


def read_init_file(*x):
    return


def redisplay(*x):
    return


def remove_history_item(*x):
    return


def replace_history_item(*x):
    return


def set_completer(*x):
    return


def set_completer_delims(*x):
    return


def set_history_length(*x):
    return


def set_pre_input_hook(*x):
    return


def set_startup_hook(*x):
    return


def write_history_file(*x):
    return
