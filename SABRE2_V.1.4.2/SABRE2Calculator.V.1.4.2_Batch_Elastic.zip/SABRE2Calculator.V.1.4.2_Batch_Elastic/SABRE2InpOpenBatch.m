function [JNodevalue,Massemble,JNodevalue_i,JNodevalue_j,Rval,BNodevalue,SNodevalue,...
   RNCc,Nshe1,Nshe2,DUP1,DUP2,NCc,Bhe1,Bhe2,The1,The2,SGhe1,SGhe2,Bhg,Thg,CSg,BNC1,BNC2,...
   FEL,error,PNC,PNC1,PNC2,LNC,LNC1,LNC2,AnalP]=SABRE2InpOpenBatch(pathname,filename,ptable_node,ptable_seg,pt_title_name,...
   JNodevalue,Massemble,JNodevalue_i,JNodevalue_j,Rval,BNodevalue,SNodevalue,...
   LNC,LUEC,BNC,BNC1,BNC2,FEL,Bhe1,Bhe2,The1,The2,SGhe1,SGhe2,Bhg,Thg,CSg,PNC,PNC1,PNC2,...
   pde_type_name,pde_jointi_edit,pde_jointj_edit,pde_bfbi_edit,pde_tfbi_edit,...
   pde_bfti_edit,pde_tfti_edit,pde_dwi_edit,pde_twi_edit,pde_bfbj_edit,...
   pde_tfbj_edit,pde_bftj_edit,pde_tftj_edit,pde_dwj_edit,pde_twj_edit,...
   pde_fili_edit,pde_filj_edit,pdesign_edit,punit_edit,pdb_member_name,...
   pdb_type_name,pdb_coordx_edit,pdb_coordy_edit,pdb_coordz_edit,...
   pdb_length_edit,pdb_bfb_edit,pdb_tfb_edit,pdb_bft_edit,pdb_tft_edit,...
   pdb_dw_edit,pdb_tw_edit,pdb_fil_edit,pdb_step_edit,vrum_az_slider,...
   vrum_el_slider,vrum_az_edit,vrum_el_edit,ptable_remove_edit,axesm,vstm,modelnum,auto_modelname_edit)            
            
% Developed by Woo Yong Jeong.
% Date : 12/01/2012.
% ************************************************************************
% *****************          INPUT FILE OPEN          ********************
% ************************************************************************

   fileID = fopen([pathname,get(auto_modelname_edit,'String'),num2str(modelnum),'.inp']);
   tmp_input=textscan(fileID,'%s','HeaderLines',3,'Delimiter','\n');
   % tmp_input=textscan(fileID,'%s');
   fclose(fileID);

   cla(axesm,'reset'); 
   % Initial View : X-Y View
   az = 0; el = 0; view(az, el);   
   JNodevalue = []; Massemble = []; 
   JNodevalue_i = []; JNodevalue_j = []; Rval=[]; BNodevalue = []; SNodevalue =[]; 
   RNCc = []; NCc = []; Nshe1 = []; Nshe2 = []; DUP1 = []; DUP2 = []; LNC = [];
   LNC1 = []; LNC2 = []; LUEC = []; PNC = []; PNC1 = []; PNC2 = []; BNC = []; FEL = [];
   BNC1 = []; BNC2 = []; t=[]; ULoad=[]; gammma=[]; Funew =[]; EGunew=[]; Qintf=[];
   Qintg=[]; Sincre=[]; Bhe1=[]; Bhe2=[]; The1=[]; The2=[]; Bhg=[]; Thg=[]; CSg=[]; tau=[]; SGhe1=[]; SGhe2=[];
   LTYPE=[]; AR=0; AS=0; AE=0; AI=0; ANE=0; ANI=0; Rpg=[]; Rpc=[]; Rpt=[]; Rh=[]; Myc=[]; My=[]; Phi_Py=[]; UC=[];
   cflag=0; LNCpv=[];LIAType=0; NLIAType=0;HomoType=0; crLTB = 0; LGv=0;     
   
   daxis=str2num(tmp_input{1}{2});
   set(pdesign_edit,'Value',daxis);
   dunit=str2num(tmp_input{1}{4});
   set(punit_edit,'Value',dunit);
    
   % celldisp(tmp_input)     
   % tmp_input{1}{1};   
   xcoord = str2num(tmp_input{1}{7});
   G_setdata(1,:) = xcoord;   
   % tmp_input{1}{5};   
   bf1 = str2num(tmp_input{1}{9});
   G_setdata(2,:) = bf1;
   % tmp_input{1}{7};   
   tf1 = str2num(tmp_input{1}{11});
   G_setdata(3,:) = tf1;
   % tmp_input{1}{9};   
   bf2 = str2num(tmp_input{1}{13});
   G_setdata(4,:) = bf2;
   % tmp_input{1}{11};   
   tf2 = str2num(tmp_input{1}{15});
   G_setdata(5,:) = tf2;
   % tmp_input{1}{13};   
   dw = str2num(tmp_input{1}{17});
   G_setdata(6,:) = dw;
   % tmp_input{1}{15};   
   tw = str2num(tmp_input{1}{19});
   G_setdata(7,:) = tw;
   % tmp_input{1}{17};   
   afillets = str2num(tmp_input{1}{21});
   G_setdata(8,:) = afillets;
   % tmp_input{1}{19};   
   Px = str2num(tmp_input{1}{23});   
   G_setdata(9,:) = Px;
   Py = str2num(tmp_input{1}{25});   
   G_setdata(10,:) = Py;   
   % tmp_input{1}{21};   
   Mz = str2num(tmp_input{1}{27});
   G_setdata(11,:) = Mz;
   % tmp_input{1}{23};   
   tfr = str2num(tmp_input{1}{29});
   G_setdata(12,:) = tfr;
   lh = str2num(tmp_input{1}{31});
   G_setdata(13,:) = lh;   
   % tmp_input{1}{25};   
   step = str2num(tmp_input{1}{33});
   G_setdata(14,:) = step;

   % tmp_input{1}{27}; 
   % tmp_input{1}{28};
   % tmp_input{1}{29};
   ele = str2num(tmp_input{1}{36});
   M_setdata(1,:) = ele;
   % tmp_input{1}{35};
   fy1 = str2num(tmp_input{1}{38});
   M_setdata(2,:) = fy1;
   fyw = str2num(tmp_input{1}{40});
   M_setdata(3,:) = fyw;
   fy2 = str2num(tmp_input{1}{42});
   M_setdata(4,:) = fy2; 

%    Jv = str2num(tmp_input{1}{47});
   AnalP(1,1) = 0;
   Jv = str2num(tmp_input{1}{45});
   AnalP(2,1) = Jv; 
   AISCv = str2num(tmp_input{1}{47});
   AnalP(3,1) = AISCv;    
   DM = str2num(tmp_input{1}{49});
   AnalP(4,1) = DM;    
   AnalP(5,1)=1; % 2nd 1
   AnalP(6,1)=1; % 2nd 2 
   dunit1=get(punit_edit,'Value');
   AnalP(7,1)=dunit1; % unit
   %----------------------------- Geometry
   
   if isequal(length(G_setdata(1,:)),2) % No internal node
      cnames_node = {'Joint 1','Joint 2'};
   elseif length(G_setdata(1,:)) > 2
      for i = 1: ( length(G_setdata(1,:))- 2 )
         if isequal(i,1)
            Gnode = ['Node ',num2str(i)];
         else
            Gnode = [Gnode;'Node ',num2str(i)];
         end
      end

      cnames_node = {'Joint 1',Gnode,'Joint 2'};

   end
   set(ptable_node,'ColumnName',cnames_node)
   set(ptable_node,'Data',G_setdata)

   % get geometry table data
   G_getdata=get(ptable_node,'Data');
   if isequal(length(G_getdata(1,:)),2)
      set(ptable_remove_edit,'String','NONE')
   else
      popnum = 1:1:(length(G_getdata(1,:))-2);
      set(ptable_remove_edit,'String',{'NONE',num2str(popnum')})      
   end    
   
   %----------------------------- Materials
   if length(M_setdata(1,:))>= 1
      for i = 1:length(M_setdata(1,:))
         if isequal(i,1)
            Mseg = ['Segment ',num2str(i)];
         else
            Mseg = [Mseg;'Segment ',num2str(i)];
         end
      end
      cnames_seg = Mseg;
      set(ptable_seg,'ColumnName',cnames_seg)
      set(ptable_seg,'Data',M_setdata) 
   end   

   [JNodevalue]=SABRE2JointApp(JNodevalue,ptable_node,pt_title_name);

   % get geometry table data   
   G_getdata=get(ptable_node,'Data');
   daxis=get(pdesign_edit,'Value');
   if ~isempty(JNodevalue)
      if isempty(daxis) || isnan(daxis) || ...
            round(daxis) <= 0 || round(daxis) > 3 
         set(pt_title_name,'String','Please define proper design axis')
         set(pt_title_name,'Visible','on') 
      else

         set(pde_type_name,'String',num2str(1))
         set(pde_jointi_edit,'String',num2str(1));
         set(pde_jointj_edit,'String',num2str(2));
         set(pde_bfbi_edit,'String',num2str(G_getdata(2,1)));
         set(pde_tfbi_edit,'String',num2str(G_getdata(3,1)));
         set(pde_bfti_edit,'String',num2str(G_getdata(4,1)));
         set(pde_tfti_edit,'String',num2str(G_getdata(5,1)));
         set(pde_dwi_edit,'String',num2str(G_getdata(6,1)));
         set(pde_twi_edit,'String',num2str(G_getdata(7,1)));
         set(pde_fili_edit,'String',num2str(G_getdata(8,1)));   
         set(pde_bfbj_edit,'String',num2str(G_getdata(2,end)));
         set(pde_tfbj_edit,'String',num2str(G_getdata(3,end)));
         set(pde_bftj_edit,'String',num2str(G_getdata(4,end)));
         set(pde_tftj_edit,'String',num2str(G_getdata(5,end)));
         set(pde_dwj_edit,'String',num2str(G_getdata(6,end)));
         set(pde_twj_edit,'String',num2str(G_getdata(7,end)));
         set(pde_filj_edit,'String',num2str(G_getdata(8,end)));  
         
%          set(pde_reference_edit,'Value',round(G_getdata(2,1)));

         [Massemble,JNodevalue_i,JNodevalue_j,Rval,...
            BNodevalue]=SABRE2MembApp(JNodevalue,Massemble,JNodevalue_i,...
            JNodevalue_j,Rval,BNodevalue,pde_type_name,pt_title_name,...
            pde_jointi_edit,pde_jointj_edit,pde_bfbi_edit,pde_tfbi_edit,...
            pde_bfti_edit,pde_tfti_edit,pde_dwi_edit,pde_twi_edit,pde_bfbj_edit,...
            pde_tfbj_edit,pde_bftj_edit,pde_tftj_edit,pde_dwj_edit,pde_twj_edit,pde_fili_edit,pde_filj_edit,...
            pdesign_edit);     
      end

      if ~isempty(Massemble) 
         steplength =[];
         if ~isequal(length(G_getdata(1,:)),2)
            for i = 1:(length(G_getdata(1,:))-2)
               set(pdb_member_name,'String',num2str(1));
               set(pdb_type_name,'String',num2str(i));
               set(pdb_coordx_edit,'String',num2str(G_getdata(1,i+1)));
               set(pdb_coordy_edit,'String',num2str(0));
               set(pdb_coordz_edit,'String',num2str(0));    
               set(pdb_length_edit,'String',num2str(G_getdata(1,i+1)));
               set(pdb_bfb_edit,'String',num2str(G_getdata(2,i+1)));
               set(pdb_tfb_edit,'String',num2str(G_getdata(3,i+1)));
               set(pdb_bft_edit,'String',num2str(G_getdata(4,i+1)));
               set(pdb_tft_edit,'String',num2str(G_getdata(5,i+1)));
               set(pdb_dw_edit,'String',num2str(G_getdata(6,i+1)));
               set(pdb_tw_edit,'String',num2str(G_getdata(7,i+1)));
               set(pdb_fil_edit,'String',num2str(G_getdata(8,i+1)));
               set(pdb_step_edit,'Value',round(G_getdata(14,i+1)))

               [BNodevalue,steplength]=SABRE2SegmApp(JNodevalue,...
                  Massemble,JNodevalue_i,JNodevalue_j,Rval,BNodevalue,pt_title_name,...
                  pdb_member_name,pdb_type_name,pdb_coordx_edit,pdb_coordy_edit,...
                  pdb_coordz_edit,pdb_length_edit,pdb_bfb_edit,pdb_tfb_edit,...
                  pdb_bft_edit,pdb_tft_edit,pdb_dw_edit,pdb_tw_edit,pdb_fil_edit,pdb_step_edit);                 

            end
         end

         [SNodevalue]=SABRE2AssiApp(BNodevalue,SNodevalue,ptable_node,ptable_seg,steplength,punit_edit,pt_title_name);

      end

   end

   SABRE2ModelP(JNodevalue,Massemble,JNodevalue_i,JNodevalue_j,Rval,...
      BNodevalue,vrum_az_slider,vrum_el_slider,vrum_az_edit,vrum_el_edit,axesm,vstm);  

   RNCc=[];Nshe1=[];Nshe2=[];DUP1=[];DUP2=[];NCc=[];Bhe1=[];Bhe2=[];
   The1=[];The2=[];Bhg=[];Thg=[]; CSg=[]; BNC1=[];BNC2=[];FEL=[]; SGhe1=[]; SGhe2=[];
   PNC=[];PNC1=[];PNC2=[]; LNC=[];LNC1=[];LNC2=[];

   if isempty(Massemble) || isempty(SNodevalue)
   else
      % Drawing Nodal white points & generate NC
      [RNCc,Nshe1,Nshe2,DUP1,DUP2,NCc,Bhe1,Bhe2,The1,The2,SGhe1,SGhe2,Bhg,Thg,CSg,BNC1,BNC2,FEL,error]=SABRE2LBCODE(JNodevalue,...
         Massemble,JNodevalue_i,JNodevalue_j,Rval,BNodevalue,SNodevalue,...
         RNCc,Nshe1,Nshe2,DUP1,DUP2,NCc,LNC,LUEC,PNC,BNC,BNC1,BNC2,FEL,Bhe1,Bhe2,The1,The2,SGhe1,SGhe2,Bhg,Thg,CSg,pt_title_name,axesm,vstm);    

      [PNC,PNC1,PNC2]=SABRE2BConApp(JNodevalue,Massemble,Rval,...
         BNodevalue,RNCc,DUP1,DUP2,PNC,PNC1,PNC2,Bhg,Thg,CSg,ptable_node,pt_title_name,axesm); 

      [LNC,LNC1,LNC2]=SABRE2ForcApp(JNodevalue,Massemble,Rval,...
         RNCc,DUP1,DUP2,LNC,LNC1,LNC2,LUEC,Nshe1,Nshe2,Bhe1,Bhe2,The1,The2,SGhe1,SGhe2,Bhg,Thg,CSg,...
         ptable_node,pt_title_name,axesm,vstm);

   end

end % function end
