# encoding: utf-8
# module PyKDE4.plasma
# from /usr/lib/python2.7/dist-packages/PyKDE4/plasma.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class Plasma():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def AbstractDialogManager(self, *args, **kwargs):  # real signature unknown
        pass

    def AbstractRunner(self, *args, **kwargs):  # real signature unknown
        pass

    def AbstractToolBox(self, *args, **kwargs):  # real signature unknown
        pass

    def AccessAppletJob(self, *args, **kwargs):  # real signature unknown
        pass

    def AccessManager(self, *args, **kwargs):  # real signature unknown
        pass

    def actionsFromMenu(self, *args, **kwargs):  # real signature unknown
        pass

    def Animation(self, *args, **kwargs):  # real signature unknown
        pass

    def AnimationDriver(self, *args, **kwargs):  # real signature unknown
        pass

    def Animator(self, *args, **kwargs):  # real signature unknown
        pass

    def AnnouncementMethod(self, *args, **kwargs):  # real signature unknown
        pass

    def Applet(self, *args, **kwargs):  # real signature unknown
        pass

    def AppletProtectedThunk(self, *args, **kwargs):  # real signature unknown
        pass

    def AppletScript(self, *args, **kwargs):  # real signature unknown
        pass

    def AspectRatioMode(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def AuthorizationInterface(self, *args, **kwargs):
        pass

    def AuthorizationManager(self, *args, **kwargs):  # real signature unknown
        pass

    def AuthorizationRule(self, *args, **kwargs):  # real signature unknown
        pass

    def BusyWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def CheckBox(self, *args, **kwargs):  # real signature unknown
        pass

    def ClientPinRequest(self, *args, **kwargs):  # real signature unknown
        pass

    def ComboBox(self, *args, **kwargs):  # real signature unknown
        pass

    def ComponentType(self, *args, **kwargs):  # real signature unknown
        pass

    def ComponentTypes(self, *args, **kwargs):  # real signature unknown
        pass

    def ConfigLoader(self, *args, **kwargs):  # real signature unknown
        pass

    def Constraint(self, *args, **kwargs):  # real signature unknown
        pass

    def Constraints(self, *args, **kwargs):  # real signature unknown
        pass

    def Containment(self, *args, **kwargs):  # real signature unknown
        pass

    def ContainmentActions(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def ContainmentActionsPluginsConfig(self, *args, **kwargs):
        pass

    def Context(self, *args, **kwargs):  # real signature unknown
        pass

    def Corona(self, *args, **kwargs):  # real signature unknown
        pass

    def DataContainer(self, *args, **kwargs):  # real signature unknown
        pass

    def DataEngine(self, *args, **kwargs):  # real signature unknown
        pass

    def DataEngineManager(self, *args, **kwargs):  # real signature unknown
        pass

    def DataEngineScript(self, *args, **kwargs):  # real signature unknown
        pass

    def DeclarativeWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def Delegate(self, *args, **kwargs):  # real signature unknown
        pass

    def Dialog(self, *args, **kwargs):  # real signature unknown
        pass

    def Direction(self, *args, **kwargs):  # real signature unknown
        pass

    def Extender(self, *args, **kwargs):  # real signature unknown
        pass

    def ExtenderGroup(self, *args, **kwargs):  # real signature unknown
        pass

    def ExtenderItem(self, *args, **kwargs):  # real signature unknown
        pass

    def FlashingLabel(self, *args, **kwargs):  # real signature unknown
        pass

    def Flip(self, *args, **kwargs):  # real signature unknown
        pass

    def FlipDirection(self, *args, **kwargs):  # real signature unknown
        pass

    def FormFactor(self, *args, **kwargs):  # real signature unknown
        pass

    def Frame(self, *args, **kwargs):  # real signature unknown
        pass

    def FrameSvg(self, *args, **kwargs):  # real signature unknown
        pass

    def GLApplet(self, *args, **kwargs):  # real signature unknown
        pass

    def GroupBox(self, *args, **kwargs):  # real signature unknown
        pass

    def IconWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def ImmutabilityType(self, *args, **kwargs):  # real signature unknown
        pass

    def IntervalAlignment(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def isPluginVersionCompatible(self, *args, **kwargs):
        pass

    def ItemBackground(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemStatus(self, *args, **kwargs):  # real signature unknown
        pass

    def ItemTypes(self, *args, **kwargs):  # real signature unknown
        pass

    def knownLanguages(self, *args, **kwargs):  # real signature unknown
        pass

    def Label(self, *args, **kwargs):  # real signature unknown
        pass

    def LineEdit(self, *args, **kwargs):  # real signature unknown
        pass

    def loadScriptEngine(self, *args, **kwargs):  # real signature unknown
        pass

    def Location(self, *args, **kwargs):  # real signature unknown
        pass

    def locationToDirection(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def locationToInverseDirection(self, *args, **kwargs):
        pass

    def MarginEdge(self, *args, **kwargs):  # real signature unknown
        pass

    def MessageButton(self, *args, **kwargs):  # real signature unknown
        pass

    def MessageButtons(self, *args, **kwargs):  # real signature unknown
        pass

    def Meter(self, *args, **kwargs):  # real signature unknown
        pass

    def Package(self, *args, **kwargs):  # real signature unknown
        pass

    def PackageMetadata(self, *args, **kwargs):  # real signature unknown
        pass

    def packageStructure(self, *args, **kwargs):  # real signature unknown
        pass

    def PackageStructure(self, *args, **kwargs):  # real signature unknown
        pass

    def PaintUtils(self, *args, **kwargs):  # real signature unknown
        pass

    def PlotColor(self, *args, **kwargs):  # real signature unknown
        pass

    def PluginLoader(self, *args, **kwargs):  # real signature unknown
        pass

    def PopupApplet(self, *args, **kwargs):  # real signature unknown
        pass

    def PopupPlacement(self, *args, **kwargs):  # real signature unknown
        pass

    def Position(self, *args, **kwargs):  # real signature unknown
        pass

    def PushButton(self, *args, **kwargs):  # real signature unknown
        pass

    def QueryMatch(self, *args, **kwargs):  # real signature unknown
        pass

    def RadioButton(self, *args, **kwargs):  # real signature unknown
        pass

    def RunnerContext(self, *args, **kwargs):  # real signature unknown
        pass

    def RunnerManager(self, *args, **kwargs):  # real signature unknown
        pass

    def RunnerScript(self, *args, **kwargs):  # real signature unknown
        pass

    def RunnerSyntax(self, *args, **kwargs):  # real signature unknown
        pass

    def scalingFactor(self, *args, **kwargs):  # real signature unknown
        pass

    def ScriptEngine(self, *args, **kwargs):  # real signature unknown
        pass

    def ScrollBar(self, *args, **kwargs):  # real signature unknown
        pass

    def ScrollWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def Separator(self, *args, **kwargs):  # real signature unknown
        pass

    def Service(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceAccessJob(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceJob(self, *args, **kwargs):  # real signature unknown
        pass

    def SignalPlotter(self, *args, **kwargs):  # real signature unknown
        pass

    def Slider(self, *args, **kwargs):  # real signature unknown
        pass

    def SpinBox(self, *args, **kwargs):  # real signature unknown
        pass

    def Svg(self, *args, **kwargs):  # real signature unknown
        pass

    def SvgWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def TabBar(self, *args, **kwargs):  # real signature unknown
        pass

    def TextBrowser(self, *args, **kwargs):  # real signature unknown
        pass

    def TextEdit(self, *args, **kwargs):  # real signature unknown
        pass

    def Theme(self, *args, **kwargs):  # real signature unknown
        pass

    def ToolButton(self, *args, **kwargs):  # real signature unknown
        pass

    def ToolTipContent(self, *args, **kwargs):  # real signature unknown
        pass

    def ToolTipManager(self, *args, **kwargs):  # real signature unknown
        pass

    def TreeView(self, *args, **kwargs):  # real signature unknown
        pass

    def TrustLevel(self, *args, **kwargs):  # real signature unknown
        pass

    def version(self, *args, **kwargs):  # real signature unknown
        pass

    def versionMajor(self, *args, **kwargs):  # real signature unknown
        pass

    def versionMinor(self, *args, **kwargs):  # real signature unknown
        pass

    def versionRelease(self, *args, **kwargs):  # real signature unknown
        pass

    def versionString(self, *args, **kwargs):  # real signature unknown
        pass

    def VideoWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def View(self, *args, **kwargs):  # real signature unknown
        pass

    def viewFor(self, *args, **kwargs):  # real signature unknown
        pass

    def Wallpaper(self, *args, **kwargs):  # real signature unknown
        pass

    def WallpaperScript(self, *args, **kwargs):  # real signature unknown
        pass

    def WebView(self, *args, **kwargs):  # real signature unknown
        pass

    def WindowEffects(self, *args, **kwargs):  # real signature unknown
        pass

    def ZoomDirection(self, *args, **kwargs):  # real signature unknown
        pass

    def ZoomLevel(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    AcceptingInputStatus = 4
    ActiveStatus = 2
    AlignToHour = 2
    AlignToMinute = 1
    AllConstraints = 223
    AnimatorComponent = 8
    AppletComponent = 1
    AppletType = 65537
    BottomEdge = 4
    BottomMargin = 1
    BottomPosedLeftAlignedPopup = 5
    BottomPosedRightAlignedPopup = 6
    BottomPositioned = 3
    ButtonCancel = 8
    ButtonNo = 4
    ButtonNone = 0
    ButtonOk = 1
    ButtonYes = 2
    CenterPositioned = 4
    ConstrainedSquare = 3
    ContainmentComponent = 16
    ContextConstraint = 64
    DataEngineComponent = 2
    Desktop = 1
    DesktopZoom = 0
    Down = 0
    FixedSize = 4
    Floating = 0
    FloatingPopup = 0
    FormFactorConstraint = 1
    FullScreen = 2
    GroupZoom = 1
    Horizontal = 2
    HorizontalFlip = 1
    IgnoreAspectRatio = 0
    ImmutableConstraint = 16
    InvalidAspectRatioMode = -1
    InvalidCredentials = 0
    KeepAspectRatio = 1
    Left = 2
    LeftEdge = 5
    LeftMargin = 2
    LeftPosedBottomAlignedPopup = 4
    LeftPosedTopAlignedPopup = 3
    LeftPositioned = 0
    LineEditType = 65538
    LocationConstraint = 2
    MediaCenter = 1
    Mutable = 1
    NeedsAttentionStatus = 3
    NoAlignment = 0
    NoAnnouncement = 0
    NoConstraint = 0
    NoFlip = 0
    OverviewZoom = 2
    PassiveStatus = 1
    Planar = 0
    PopupConstraint = 128
    Right = 3
    RightEdge = 6
    RightMargin = 3
    RightPosedBottomAlignedPopup = 8
    RightPosedTopAlignedPopup = 7
    RightPositioned = 1
    RunnerComponent = 4
    ScreenConstraint = 4
    SizeConstraint = 8
    Square = 2
    StartupCompletedConstraint = 32
    SystemImmutable = 4
    TopEdge = 3
    TopMargin = 0
    TopPosedLeftAlignedPopup = 1
    TopPosedRightAlignedPopup = 2
    TopPositioned = 2
    TrustedCredentials = 3
    UltimateCredentials = 4
    UnknownCredentials = 1
    UnknownStatus = 0
    Up = 1
    UserImmutable = 2
    ValidCredentials = 2
    Vertical = 3
    VerticalFlip = 2
    WallpaperComponent = 32
    ZeroconfAnnouncement = 1
    ZoomIn = 0
    ZoomOut = 1
