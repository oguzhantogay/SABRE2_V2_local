# encoding: utf-8
# module scipy.integrate._quadpack
# from /usr/lib/python2.7/dist-packages/scipy/integrate/_quadpack.so by generator 1.96
# no doc
# no imports

# Variables with simple values

__version__ = ' 1.13 '

# functions

# real signature unknown; NOTE: unreliably restored from __doc__


def _qagie(fun, bound, inf, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qagie(fun, bound, inf, | args, full_output, epsabs, epsrel, limit) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qagpe(fun, a, b, points, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qagpe(fun, a, b, points, | args, full_output, epsabs, epsrel, limit) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qagse(fun, a, b, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qagse(fun, a, b, | args, full_output, epsabs, epsrel, limit) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qawce(fun, a, b, c, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qawce(fun, a, b, c, | args, full_output, epsabs, epsrel, limit) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qawfe(fun, a, omega, integr, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qawfe(fun, a, omega, integr, | args, full_output, epsabs, limlst, limit, maxp1) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qawoe(fun, a, b, omega, integr, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qawoe(fun, a, b, omega, integr, | args, full_output, epsabs, epsrel, limit, maxp1, icall, momcom, chebmo) """
    pass


# real signature unknown; NOTE: unreliably restored from __doc__
def _qawse(fun, a, b, (alfa, beta), integr, *args, **kwargs):
    """ [result,abserr,infodict,ier] = _qawse(fun, a, b, (alfa, beta), integr, | args, full_output, epsabs, epsrel, limit) """
    pass


# classes

class error(Exception):
    # no doc

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
