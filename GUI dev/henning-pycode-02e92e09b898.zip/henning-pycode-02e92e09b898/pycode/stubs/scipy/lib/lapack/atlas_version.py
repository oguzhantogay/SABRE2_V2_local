# encoding: utf-8
# module scipy.lib.lapack.atlas_version
# from /usr/lib/python2.7/dist-packages/scipy/lib/lapack/atlas_version.so by generator 1.96
# no doc
# no imports

# functions


def version(*args, **kwargs):  # real signature unknown
    """ Print the build info from atlas. """
    pass


# no classes
