# encoding: utf-8
# module scipy.stats.futil
# from /usr/lib/python2.7/dist-packages/scipy/stats/futil.so by generator 1.96
"""
This module 'futil' is auto-generated with f2py (version:1).
Functions:
  arr = dqsort(arr,overwrite_arr=0)
  replist,repnum,nlist = dfreps(arr)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

dfreps = None  # (!) real value is ''

dqsort = None  # (!) real value is ''
