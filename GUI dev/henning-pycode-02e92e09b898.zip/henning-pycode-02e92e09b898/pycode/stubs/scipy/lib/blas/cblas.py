# encoding: utf-8
# module scipy.lib.blas.cblas
# from /usr/lib/python2.7/dist-packages/scipy/lib/blas/cblas.so by
# generator 1.96
"""
This module 'cblas' is auto-generated with f2py (version:1).
Functions:
  empty_module()
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

empty_module = None  # (!) real value is ''
