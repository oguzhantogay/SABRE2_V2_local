# encoding: utf-8
# module scipy.cluster._vq
# from /usr/lib/python2.7/dist-packages/scipy/cluster/_vq.so by generator 1.96
# no doc
# no imports

# functions


def vq(*args, **kwargs):  # real signature unknown
    """ TODO docstring """
    pass


# no classes
