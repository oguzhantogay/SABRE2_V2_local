# encoding: utf-8
# module scipy.integrate.vode
# from /usr/lib/python2.7/dist-packages/scipy/integrate/vode.so by
# generator 1.96
"""
This module 'vode' is auto-generated with f2py (version:1).
Functions:
  y,t,istate = dvode(f,jac,y,t,tout,rtol,atol,itask,istate,rwork,iwork,mf,f_extra_args=(),jac_extra_args=(),overwrite_y=0)
  y,t,istate = zvode(f,jac,y,t,tout,rtol,atol,itask,istate,zwork,rwork,iwork,mf,f_extra_args=(),jac_extra_args=(),overwrite_y=0)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

dvode = None  # (!) real value is ''

zvode = None  # (!) real value is ''
