# encoding: utf-8
# module PyQt4.QtXml
# from /usr/lib/python2.7/dist-packages/PyQt4/QtXml.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class QDomNode():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QDomNode()
    QDomNode(QDomNode)
    """
    # real signature unknown; restored from __doc__

    def appendChild(self, QDomNode):
        """ QDomNode.appendChild(QDomNode) -> QDomNode """
        return QDomNode

    def attributes(self):  # real signature unknown; restored from __doc__
        """ QDomNode.attributes() -> QDomNamedNodeMap """
        return QDomNamedNodeMap

    def childNodes(self):  # real signature unknown; restored from __doc__
        """ QDomNode.childNodes() -> QDomNodeList """
        return QDomNodeList

    def clear(self):  # real signature unknown; restored from __doc__
        """ QDomNode.clear() """
        pass

    # real signature unknown; restored from __doc__
    def cloneNode(self, bool_deep=True):
        """ QDomNode.cloneNode(bool deep=True) -> QDomNode """
        return QDomNode

    def columnNumber(self):  # real signature unknown; restored from __doc__
        """ QDomNode.columnNumber() -> int """
        return 0

    def EncodingPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def firstChild(self):  # real signature unknown; restored from __doc__
        """ QDomNode.firstChild() -> QDomNode """
        return QDomNode

    # real signature unknown; NOTE: unreliably restored from __doc__
    def firstChildElement(self, QString_tagName=None, *args, **kwargs):
        """ QDomNode.firstChildElement(QString tagName=QString()) -> QDomElement """
        pass

    def hasAttributes(self):  # real signature unknown; restored from __doc__
        """ QDomNode.hasAttributes() -> bool """
        return False

    def hasChildNodes(self):  # real signature unknown; restored from __doc__
        """ QDomNode.hasChildNodes() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def insertAfter(self, QDomNode, QDomNode_1):
        """ QDomNode.insertAfter(QDomNode, QDomNode) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def insertBefore(self, QDomNode, QDomNode_1):
        """ QDomNode.insertBefore(QDomNode, QDomNode) -> QDomNode """
        return QDomNode

    def isAttr(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isAttr() -> bool """
        return False

    def isCDATASection(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isCDATASection() -> bool """
        return False

    def isCharacterData(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isCharacterData() -> bool """
        return False

    def isComment(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isComment() -> bool """
        return False

    def isDocument(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isDocument() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def isDocumentFragment(self):
        """ QDomNode.isDocumentFragment() -> bool """
        return False

    def isDocumentType(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isDocumentType() -> bool """
        return False

    def isElement(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isElement() -> bool """
        return False

    def isEntity(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isEntity() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def isEntityReference(self):
        """ QDomNode.isEntityReference() -> bool """
        return False

    def isNotation(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isNotation() -> bool """
        return False

    def isNull(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isNull() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def isProcessingInstruction(self):
        """ QDomNode.isProcessingInstruction() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def isSupported(self, QString, QString_1):
        """ QDomNode.isSupported(QString, QString) -> bool """
        return False

    def isText(self):  # real signature unknown; restored from __doc__
        """ QDomNode.isText() -> bool """
        return False

    def lastChild(self):  # real signature unknown; restored from __doc__
        """ QDomNode.lastChild() -> QDomNode """
        return QDomNode

    # real signature unknown; NOTE: unreliably restored from __doc__
    def lastChildElement(self, QString_tagName=None, *args, **kwargs):
        """ QDomNode.lastChildElement(QString tagName=QString()) -> QDomElement """
        pass

    def lineNumber(self):  # real signature unknown; restored from __doc__
        """ QDomNode.lineNumber() -> int """
        return 0

    def localName(self):  # real signature unknown; restored from __doc__
        """ QDomNode.localName() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def namedItem(self, QString):
        """ QDomNode.namedItem(QString) -> QDomNode """
        return QDomNode

    def namespaceURI(self):  # real signature unknown; restored from __doc__
        """ QDomNode.namespaceURI() -> QString """
        pass

    def nextSibling(self):  # real signature unknown; restored from __doc__
        """ QDomNode.nextSibling() -> QDomNode """
        return QDomNode

    # real signature unknown; NOTE: unreliably restored from __doc__
    def nextSiblingElement(self, QString_tagName=None, *args, **kwargs):
        """ QDomNode.nextSiblingElement(QString tagName=QString()) -> QDomElement """
        pass

    def nodeName(self):  # real signature unknown; restored from __doc__
        """ QDomNode.nodeName() -> QString """
        pass

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomNode.nodeType() -> QDomNode.NodeType """
        pass

    def NodeType(self, *args, **kwargs):  # real signature unknown
        pass

    def nodeValue(self):  # real signature unknown; restored from __doc__
        """ QDomNode.nodeValue() -> QString """
        pass

    def normalize(self):  # real signature unknown; restored from __doc__
        """ QDomNode.normalize() """
        pass

    def ownerDocument(self):  # real signature unknown; restored from __doc__
        """ QDomNode.ownerDocument() -> QDomDocument """
        return QDomDocument

    def parentNode(self):  # real signature unknown; restored from __doc__
        """ QDomNode.parentNode() -> QDomNode """
        return QDomNode

    def prefix(self):  # real signature unknown; restored from __doc__
        """ QDomNode.prefix() -> QString """
        pass

    def previousSibling(self):  # real signature unknown; restored from __doc__
        """ QDomNode.previousSibling() -> QDomNode """
        return QDomNode

    # real signature unknown; NOTE: unreliably restored from __doc__
    def previousSiblingElement(self, QString_tagName=None, *args, **kwargs):
        """ QDomNode.previousSiblingElement(QString tagName=QString()) -> QDomElement """
        pass

    # real signature unknown; restored from __doc__
    def removeChild(self, QDomNode):
        """ QDomNode.removeChild(QDomNode) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def replaceChild(self, QDomNode, QDomNode_1):
        """ QDomNode.replaceChild(QDomNode, QDomNode) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__ with multiple overloads
    def save(self, QTextStream, p_int, QDomNode_EncodingPolicy=None):
        """
        QDomNode.save(QTextStream, int)
        QDomNode.save(QTextStream, int, QDomNode.EncodingPolicy)
        """
        pass

    # real signature unknown; restored from __doc__
    def setNodeValue(self, QString):
        """ QDomNode.setNodeValue(QString) """
        pass

    # real signature unknown; restored from __doc__
    def setPrefix(self, QString):
        """ QDomNode.setPrefix(QString) """
        pass

    def toAttr(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toAttr() -> QDomAttr """
        return QDomAttr

    def toCDATASection(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toCDATASection() -> QDomCDATASection """
        return QDomCDATASection

    def toCharacterData(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toCharacterData() -> QDomCharacterData """
        return QDomCharacterData

    def toComment(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toComment() -> QDomComment """
        return QDomComment

    def toDocument(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toDocument() -> QDomDocument """
        return QDomDocument

    # real signature unknown; restored from __doc__
    def toDocumentFragment(self):
        """ QDomNode.toDocumentFragment() -> QDomDocumentFragment """
        return QDomDocumentFragment

    def toDocumentType(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toDocumentType() -> QDomDocumentType """
        return QDomDocumentType

    def toElement(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toElement() -> QDomElement """
        return QDomElement

    def toEntity(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toEntity() -> QDomEntity """
        return QDomEntity

    # real signature unknown; restored from __doc__
    def toEntityReference(self):
        """ QDomNode.toEntityReference() -> QDomEntityReference """
        return QDomEntityReference

    def toNotation(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toNotation() -> QDomNotation """
        return QDomNotation

    # real signature unknown; restored from __doc__
    def toProcessingInstruction(self):
        """ QDomNode.toProcessingInstruction() -> QDomProcessingInstruction """
        return QDomProcessingInstruction

    def toText(self):  # real signature unknown; restored from __doc__
        """ QDomNode.toText() -> QDomText """
        return QDomText

    def __eq__(self, y):  # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomNode=None):
        pass

    def __le__(self, y):  # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object())  # default

    AttributeNode = 2
    BaseNode = 21
    CDATASectionNode = 4
    CharacterDataNode = 22
    CommentNode = 8
    DocumentFragmentNode = 11
    DocumentNode = 9
    DocumentTypeNode = 10
    ElementNode = 1
    EncodingFromDocument = 1
    EncodingFromTextStream = 2
    EntityNode = 6
    EntityReferenceNode = 5
    NotationNode = 12
    ProcessingInstructionNode = 7
    TextNode = 3


class QDomAttr(QDomNode):

    """
    QDomAttr()
    QDomAttr(QDomAttr)
    """

    def name(self):  # real signature unknown; restored from __doc__
        """ QDomAttr.name() -> QString """
        pass

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomAttr.nodeType() -> QDomNode.NodeType """
        pass

    def ownerElement(self):  # real signature unknown; restored from __doc__
        """ QDomAttr.ownerElement() -> QDomElement """
        return QDomElement

    # real signature unknown; restored from __doc__
    def setValue(self, QString):
        """ QDomAttr.setValue(QString) """
        pass

    def specified(self):  # real signature unknown; restored from __doc__
        """ QDomAttr.specified() -> bool """
        return False

    def value(self):  # real signature unknown; restored from __doc__
        """ QDomAttr.value() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomAttr=None):
        pass


class QDomCharacterData(QDomNode):

    """
    QDomCharacterData()
    QDomCharacterData(QDomCharacterData)
    """
    # real signature unknown; restored from __doc__

    def appendData(self, QString):
        """ QDomCharacterData.appendData(QString) """
        pass

    def data(self):  # real signature unknown; restored from __doc__
        """ QDomCharacterData.data() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def deleteData(self, p_int, p_int_1):
        """ QDomCharacterData.deleteData(int, int) """
        pass

    # real signature unknown; restored from __doc__
    def insertData(self, p_int, QString):
        """ QDomCharacterData.insertData(int, QString) """
        pass

    def length(self):  # real signature unknown; restored from __doc__
        """ QDomCharacterData.length() -> int """
        return 0

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomCharacterData.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__
    def replaceData(self, p_int, p_int_1, QString):
        """ QDomCharacterData.replaceData(int, int, QString) """
        pass

    # real signature unknown; restored from __doc__
    def setData(self, QString):
        """ QDomCharacterData.setData(QString) """
        pass

    # real signature unknown; restored from __doc__
    def substringData(self, p_int, p_int_1):
        """ QDomCharacterData.substringData(int, int) -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomCharacterData=None):
        pass


class QDomText(QDomCharacterData):

    """
    QDomText()
    QDomText(QDomText)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomText.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__
    def splitText(self, p_int):
        """ QDomText.splitText(int) -> QDomText """
        return QDomText

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomText=None):
        pass


class QDomCDATASection(QDomText):

    """
    QDomCDATASection()
    QDomCDATASection(QDomCDATASection)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomCDATASection.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomCDATASection=None):
        pass


class QDomComment(QDomCharacterData):

    """
    QDomComment()
    QDomComment(QDomComment)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomComment.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomComment=None):
        pass


class QDomDocument(QDomNode):

    """
    QDomDocument()
    QDomDocument(QString)
    QDomDocument(QDomDocumentType)
    QDomDocument(QDomDocument)
    """
    # real signature unknown; restored from __doc__

    def createAttribute(self, QString):
        """ QDomDocument.createAttribute(QString) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__
    def createAttributeNS(self, QString, QString_1):
        """ QDomDocument.createAttributeNS(QString, QString) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__
    def createCDATASection(self, QString):
        """ QDomDocument.createCDATASection(QString) -> QDomCDATASection """
        return QDomCDATASection

    # real signature unknown; restored from __doc__
    def createComment(self, QString):
        """ QDomDocument.createComment(QString) -> QDomComment """
        return QDomComment

    # real signature unknown; restored from __doc__
    def createDocumentFragment(self):
        """ QDomDocument.createDocumentFragment() -> QDomDocumentFragment """
        return QDomDocumentFragment

    # real signature unknown; restored from __doc__
    def createElement(self, QString):
        """ QDomDocument.createElement(QString) -> QDomElement """
        return QDomElement

    # real signature unknown; restored from __doc__
    def createElementNS(self, QString, QString_1):
        """ QDomDocument.createElementNS(QString, QString) -> QDomElement """
        return QDomElement

    # real signature unknown; restored from __doc__
    def createEntityReference(self, QString):
        """ QDomDocument.createEntityReference(QString) -> QDomEntityReference """
        return QDomEntityReference

    # real signature unknown; restored from __doc__
    def createProcessingInstruction(self, QString, QString_1):
        """ QDomDocument.createProcessingInstruction(QString, QString) -> QDomProcessingInstruction """
        return QDomProcessingInstruction

    # real signature unknown; restored from __doc__
    def createTextNode(self, QString):
        """ QDomDocument.createTextNode(QString) -> QDomText """
        return QDomText

    def doctype(self):  # real signature unknown; restored from __doc__
        """ QDomDocument.doctype() -> QDomDocumentType """
        return QDomDocumentType

    def documentElement(self):  # real signature unknown; restored from __doc__
        """ QDomDocument.documentElement() -> QDomElement """
        return QDomElement

    # real signature unknown; restored from __doc__
    def elementById(self, QString):
        """ QDomDocument.elementById(QString) -> QDomElement """
        return QDomElement

    # real signature unknown; restored from __doc__
    def elementsByTagName(self, QString):
        """ QDomDocument.elementsByTagName(QString) -> QDomNodeList """
        return QDomNodeList

    # real signature unknown; restored from __doc__
    def elementsByTagNameNS(self, QString, QString_1):
        """ QDomDocument.elementsByTagNameNS(QString, QString) -> QDomNodeList """
        return QDomNodeList

    def implementation(self):  # real signature unknown; restored from __doc__
        """ QDomDocument.implementation() -> QDomImplementation """
        return QDomImplementation

    # real signature unknown; restored from __doc__
    def importNode(self, QDomNode, bool):
        """ QDomDocument.importNode(QDomNode, bool) -> QDomNode """
        return QDomNode

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomDocument.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def setContent(self, *__args):
        """
        QDomDocument.setContent(QByteArray, bool) -> (bool, QString, int, int)
        QDomDocument.setContent(QString, bool) -> (bool, QString, int, int)
        QDomDocument.setContent(QIODevice, bool) -> (bool, QString, int, int)
        QDomDocument.setContent(QXmlInputSource, bool) -> (bool, QString, int, int)
        QDomDocument.setContent(QByteArray) -> (bool, QString, int, int)
        QDomDocument.setContent(QString) -> (bool, QString, int, int)
        QDomDocument.setContent(QIODevice) -> (bool, QString, int, int)
        QDomDocument.setContent(QXmlInputSource, QXmlReader) -> (bool, QString, int, int)
        """
        pass

    # real signature unknown; restored from __doc__
    def toByteArray(self, int_indent=1):
        """ QDomDocument.toByteArray(int indent=1) -> QByteArray """
        pass

    # real signature unknown; restored from __doc__
    def toString(self, int_indent=1):
        """ QDomDocument.toString(int indent=1) -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, *__args):
        pass


class QDomDocumentFragment(QDomNode):

    """
    QDomDocumentFragment()
    QDomDocumentFragment(QDomDocumentFragment)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentFragment.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomDocumentFragment=None):
        pass


class QDomDocumentType(QDomNode):

    """
    QDomDocumentType()
    QDomDocumentType(QDomDocumentType)
    """

    def entities(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.entities() -> QDomNamedNodeMap """
        return QDomNamedNodeMap

    def internalSubset(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.internalSubset() -> QString """
        pass

    def name(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.name() -> QString """
        pass

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.nodeType() -> QDomNode.NodeType """
        pass

    def notations(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.notations() -> QDomNamedNodeMap """
        return QDomNamedNodeMap

    def publicId(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.publicId() -> QString """
        pass

    def systemId(self):  # real signature unknown; restored from __doc__
        """ QDomDocumentType.systemId() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomDocumentType=None):
        pass


class QDomElement(QDomNode):

    """
    QDomElement()
    QDomElement(QDomElement)
    """
    # real signature unknown; NOTE: unreliably restored from __doc__

    def attribute(self, QString, QString_defaultValue=None, *args, **kwargs):
        """ QDomElement.attribute(QString, QString defaultValue=QString()) -> QString """
        pass

    # real signature unknown; restored from __doc__
    def attributeNode(self, QString):
        """ QDomElement.attributeNode(QString) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__
    def attributeNodeNS(self, QString, QString_1):
        """ QDomElement.attributeNodeNS(QString, QString) -> QDomAttr """
        return QDomAttr

    # real signature unknown; NOTE: unreliably restored from __doc__
    def attributeNS(self, QString, QString_1, QString_defaultValue=None, *args, **kwargs):
        """ QDomElement.attributeNS(QString, QString, QString defaultValue=QString()) -> QString """
        pass

    def attributes(self):  # real signature unknown; restored from __doc__
        """ QDomElement.attributes() -> QDomNamedNodeMap """
        return QDomNamedNodeMap

    # real signature unknown; restored from __doc__
    def elementsByTagName(self, QString):
        """ QDomElement.elementsByTagName(QString) -> QDomNodeList """
        return QDomNodeList

    # real signature unknown; restored from __doc__
    def elementsByTagNameNS(self, QString, QString_1):
        """ QDomElement.elementsByTagNameNS(QString, QString) -> QDomNodeList """
        return QDomNodeList

    # real signature unknown; restored from __doc__
    def hasAttribute(self, QString):
        """ QDomElement.hasAttribute(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def hasAttributeNS(self, QString, QString_1):
        """ QDomElement.hasAttributeNS(QString, QString) -> bool """
        return False

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomElement.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__
    def removeAttribute(self, QString):
        """ QDomElement.removeAttribute(QString) """
        pass

    # real signature unknown; restored from __doc__
    def removeAttributeNode(self, QDomAttr):
        """ QDomElement.removeAttributeNode(QDomAttr) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__
    def removeAttributeNS(self, QString, QString_1):
        """ QDomElement.removeAttributeNS(QString, QString) """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def setAttribute(self, QString, *__args):
        """
        QDomElement.setAttribute(QString, QString)
        QDomElement.setAttribute(QString, int)
        QDomElement.setAttribute(QString, int)
        QDomElement.setAttribute(QString, float)
        QDomElement.setAttribute(QString, int)
        """
        pass

    # real signature unknown; restored from __doc__
    def setAttributeNode(self, QDomAttr):
        """ QDomElement.setAttributeNode(QDomAttr) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__
    def setAttributeNodeNS(self, QDomAttr):
        """ QDomElement.setAttributeNodeNS(QDomAttr) -> QDomAttr """
        return QDomAttr

    # real signature unknown; restored from __doc__ with multiple overloads
    def setAttributeNS(self, QString, QString_1, *__args):
        """
        QDomElement.setAttributeNS(QString, QString, QString)
        QDomElement.setAttributeNS(QString, QString, int)
        QDomElement.setAttributeNS(QString, QString, int)
        QDomElement.setAttributeNS(QString, QString, float)
        QDomElement.setAttributeNS(QString, QString, int)
        """
        pass

    # real signature unknown; restored from __doc__
    def setTagName(self, QString):
        """ QDomElement.setTagName(QString) """
        pass

    def tagName(self):  # real signature unknown; restored from __doc__
        """ QDomElement.tagName() -> QString """
        pass

    def text(self):  # real signature unknown; restored from __doc__
        """ QDomElement.text() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomElement=None):
        pass


class QDomEntity(QDomNode):

    """
    QDomEntity()
    QDomEntity(QDomEntity)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomEntity.nodeType() -> QDomNode.NodeType """
        pass

    def notationName(self):  # real signature unknown; restored from __doc__
        """ QDomEntity.notationName() -> QString """
        pass

    def publicId(self):  # real signature unknown; restored from __doc__
        """ QDomEntity.publicId() -> QString """
        pass

    def systemId(self):  # real signature unknown; restored from __doc__
        """ QDomEntity.systemId() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomEntity=None):
        pass


class QDomEntityReference(QDomNode):

    """
    QDomEntityReference()
    QDomEntityReference(QDomEntityReference)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomEntityReference.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomEntityReference=None):
        pass


class QDomImplementation():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QDomImplementation()
    QDomImplementation(QDomImplementation)
    """
    # real signature unknown; restored from __doc__

    def createDocument(self, QString, QString_1, QDomDocumentType):
        """ QDomImplementation.createDocument(QString, QString, QDomDocumentType) -> QDomDocument """
        return QDomDocument

    # real signature unknown; restored from __doc__
    def createDocumentType(self, QString, QString_1, QString_2):
        """ QDomImplementation.createDocumentType(QString, QString, QString) -> QDomDocumentType """
        return QDomDocumentType

    # real signature unknown; restored from __doc__
    def hasFeature(self, QString, QString_1):
        """ QDomImplementation.hasFeature(QString, QString) -> bool """
        return False

    def InvalidDataPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown; restored from __doc__
    def invalidDataPolicy(self):
        """ QDomImplementation.invalidDataPolicy() -> QDomImplementation.InvalidDataPolicy """
        pass

    def isNull(self):  # real signature unknown; restored from __doc__
        """ QDomImplementation.isNull() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def setInvalidDataPolicy(self, QDomImplementation_InvalidDataPolicy):
        """ QDomImplementation.setInvalidDataPolicy(QDomImplementation.InvalidDataPolicy) """
        pass

    def __eq__(self, y):  # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomImplementation=None):
        pass

    def __le__(self, y):  # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object())  # default

    AcceptInvalidChars = 0
    DropInvalidChars = 1
    ReturnNullNode = 2


class QDomNamedNodeMap():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QDomNamedNodeMap()
    QDomNamedNodeMap(QDomNamedNodeMap)
    """
    # real signature unknown; restored from __doc__

    def contains(self, QString):
        """ QDomNamedNodeMap.contains(QString) -> bool """
        return False

    def count(self):  # real signature unknown; restored from __doc__
        """ QDomNamedNodeMap.count() -> int """
        return 0

    def isEmpty(self):  # real signature unknown; restored from __doc__
        """ QDomNamedNodeMap.isEmpty() -> bool """
        return False

    def item(self, p_int):  # real signature unknown; restored from __doc__
        """ QDomNamedNodeMap.item(int) -> QDomNode """
        return QDomNode

    def length(self):  # real signature unknown; restored from __doc__
        """ QDomNamedNodeMap.length() -> int """
        return 0

    # real signature unknown; restored from __doc__
    def namedItem(self, QString):
        """ QDomNamedNodeMap.namedItem(QString) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def namedItemNS(self, QString, QString_1):
        """ QDomNamedNodeMap.namedItemNS(QString, QString) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def removeNamedItem(self, QString):
        """ QDomNamedNodeMap.removeNamedItem(QString) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def removeNamedItemNS(self, QString, QString_1):
        """ QDomNamedNodeMap.removeNamedItemNS(QString, QString) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def setNamedItem(self, QDomNode):
        """ QDomNamedNodeMap.setNamedItem(QDomNode) -> QDomNode """
        return QDomNode

    # real signature unknown; restored from __doc__
    def setNamedItemNS(self, QDomNode):
        """ QDomNamedNodeMap.setNamedItemNS(QDomNode) -> QDomNode """
        return QDomNode

    def size(self):  # real signature unknown; restored from __doc__
        """ QDomNamedNodeMap.size() -> int """
        return 0

    def __eq__(self, y):  # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomNamedNodeMap=None):
        pass

    def __len__(self):  # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    def __le__(self, y):  # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object())  # default


class QDomNodeList():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QDomNodeList()
    QDomNodeList(QDomNodeList)
    """

    def at(self, p_int):  # real signature unknown; restored from __doc__
        """ QDomNodeList.at(int) -> QDomNode """
        return QDomNode

    def count(self):  # real signature unknown; restored from __doc__
        """ QDomNodeList.count() -> int """
        return 0

    def isEmpty(self):  # real signature unknown; restored from __doc__
        """ QDomNodeList.isEmpty() -> bool """
        return False

    def item(self, p_int):  # real signature unknown; restored from __doc__
        """ QDomNodeList.item(int) -> QDomNode """
        return QDomNode

    def length(self):  # real signature unknown; restored from __doc__
        """ QDomNodeList.length() -> int """
        return 0

    def size(self):  # real signature unknown; restored from __doc__
        """ QDomNodeList.size() -> int """
        return 0

    def __eq__(self, y):  # real signature unknown; restored from __doc__
        """ x.__eq__(y) <==> x==y """
        pass

    def __ge__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ge__(y) <==> x>=y """
        pass

    def __gt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__gt__(y) <==> x>y """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomNodeList=None):
        pass

    def __len__(self):  # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    def __le__(self, y):  # real signature unknown; restored from __doc__
        """ x.__le__(y) <==> x<=y """
        pass

    def __lt__(self, y):  # real signature unknown; restored from __doc__
        """ x.__lt__(y) <==> x<y """
        pass

    def __ne__(self, y):  # real signature unknown; restored from __doc__
        """ x.__ne__(y) <==> x!=y """
        pass

    __weakref__ = property(lambda self: object())  # default


class QDomNotation(QDomNode):

    """
    QDomNotation()
    QDomNotation(QDomNotation)
    """

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomNotation.nodeType() -> QDomNode.NodeType """
        pass

    def publicId(self):  # real signature unknown; restored from __doc__
        """ QDomNotation.publicId() -> QString """
        pass

    def systemId(self):  # real signature unknown; restored from __doc__
        """ QDomNotation.systemId() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomNotation=None):
        pass


class QDomProcessingInstruction(QDomNode):

    """
    QDomProcessingInstruction()
    QDomProcessingInstruction(QDomProcessingInstruction)
    """

    def data(self):  # real signature unknown; restored from __doc__
        """ QDomProcessingInstruction.data() -> QString """
        pass

    def nodeType(self):  # real signature unknown; restored from __doc__
        """ QDomProcessingInstruction.nodeType() -> QDomNode.NodeType """
        pass

    # real signature unknown; restored from __doc__
    def setData(self, QString):
        """ QDomProcessingInstruction.setData(QString) """
        pass

    def target(self):  # real signature unknown; restored from __doc__
        """ QDomProcessingInstruction.target() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QDomProcessingInstruction=None):
        pass


class QXmlAttributes():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlAttributes()
    QXmlAttributes(QXmlAttributes)
    """
    # real signature unknown; restored from __doc__

    def append(self, QString, QString_1, QString_2, QString_3):
        """ QXmlAttributes.append(QString, QString, QString, QString) """
        pass

    def clear(self):  # real signature unknown; restored from __doc__
        """ QXmlAttributes.clear() """
        pass

    def count(self):  # real signature unknown; restored from __doc__
        """ QXmlAttributes.count() -> int """
        return 0

    # real signature unknown; restored from __doc__ with multiple overloads
    def index(self, QString, QString_1=None):
        """
        QXmlAttributes.index(QString) -> int
        QXmlAttributes.index(QString, QString) -> int
        """
        return 0

    def length(self):  # real signature unknown; restored from __doc__
        """ QXmlAttributes.length() -> int """
        return 0

    # real signature unknown; restored from __doc__
    def localName(self, p_int):
        """ QXmlAttributes.localName(int) -> QString """
        pass

    def qName(self, p_int):  # real signature unknown; restored from __doc__
        """ QXmlAttributes.qName(int) -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def type(self, *__args):
        """
        QXmlAttributes.type(int) -> QString
        QXmlAttributes.type(QString) -> QString
        QXmlAttributes.type(QString, QString) -> QString
        """
        pass

    def uri(self, p_int):  # real signature unknown; restored from __doc__
        """ QXmlAttributes.uri(int) -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def value(self, *__args):
        """
        QXmlAttributes.value(int) -> QString
        QXmlAttributes.value(QString) -> QString
        QXmlAttributes.value(QString, QString) -> QString
        """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlAttributes=None):
        pass

    def __len__(self):  # real signature unknown; restored from __doc__
        """ x.__len__() <==> len(x) """
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlContentHandler():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlContentHandler()
    QXmlContentHandler(QXmlContentHandler)
    """
    # real signature unknown; restored from __doc__

    def characters(self, QString):
        """ QXmlContentHandler.characters(QString) -> bool """
        return False

    def endDocument(self):  # real signature unknown; restored from __doc__
        """ QXmlContentHandler.endDocument() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endElement(self, QString, QString_1, QString_2):
        """ QXmlContentHandler.endElement(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endPrefixMapping(self, QString):
        """ QXmlContentHandler.endPrefixMapping(QString) -> bool """
        return False

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlContentHandler.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def ignorableWhitespace(self, QString):
        """ QXmlContentHandler.ignorableWhitespace(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def processingInstruction(self, QString, QString_1):
        """ QXmlContentHandler.processingInstruction(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def setDocumentLocator(self, QXmlLocator):
        """ QXmlContentHandler.setDocumentLocator(QXmlLocator) """
        pass

    # real signature unknown; restored from __doc__
    def skippedEntity(self, QString):
        """ QXmlContentHandler.skippedEntity(QString) -> bool """
        return False

    def startDocument(self):  # real signature unknown; restored from __doc__
        """ QXmlContentHandler.startDocument() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startElement(self, QString, QString_1, QString_2, QXmlAttributes):
        """ QXmlContentHandler.startElement(QString, QString, QString, QXmlAttributes) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startPrefixMapping(self, QString, QString_1):
        """ QXmlContentHandler.startPrefixMapping(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlContentHandler=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlDeclHandler():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlDeclHandler()
    QXmlDeclHandler(QXmlDeclHandler)
    """
    # real signature unknown; restored from __doc__

    def attributeDecl(self, QString, QString_1, QString_2, QString_3, QString_4):
        """ QXmlDeclHandler.attributeDecl(QString, QString, QString, QString, QString) -> bool """
        return False

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlDeclHandler.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def externalEntityDecl(self, QString, QString_1, QString_2):
        """ QXmlDeclHandler.externalEntityDecl(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def internalEntityDecl(self, QString, QString_1):
        """ QXmlDeclHandler.internalEntityDecl(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlDeclHandler=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlDTDHandler():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlDTDHandler()
    QXmlDTDHandler(QXmlDTDHandler)
    """

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlDTDHandler.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def notationDecl(self, QString, QString_1, QString_2):
        """ QXmlDTDHandler.notationDecl(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def unparsedEntityDecl(self, QString, QString_1, QString_2, QString_3):
        """ QXmlDTDHandler.unparsedEntityDecl(QString, QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlDTDHandler=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlEntityResolver():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlEntityResolver()
    QXmlEntityResolver(QXmlEntityResolver)
    """

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlEntityResolver.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def resolveEntity(self, QString, QString_1):
        """ QXmlEntityResolver.resolveEntity(QString, QString) -> (bool, QXmlInputSource) """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlEntityResolver=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlErrorHandler():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlErrorHandler()
    QXmlErrorHandler(QXmlErrorHandler)
    """
    # real signature unknown; restored from __doc__

    def error(self, QXmlParseException):
        """ QXmlErrorHandler.error(QXmlParseException) -> bool """
        return False

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlErrorHandler.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def fatalError(self, QXmlParseException):
        """ QXmlErrorHandler.fatalError(QXmlParseException) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def warning(self, QXmlParseException):
        """ QXmlErrorHandler.warning(QXmlParseException) -> bool """
        return False

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlErrorHandler=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlLexicalHandler():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlLexicalHandler()
    QXmlLexicalHandler(QXmlLexicalHandler)
    """

    # real signature unknown; restored from __doc__
    def comment(self, QString):
        """ QXmlLexicalHandler.comment(QString) -> bool """
        return False

    def endCDATA(self):  # real signature unknown; restored from __doc__
        """ QXmlLexicalHandler.endCDATA() -> bool """
        return False

    def endDTD(self):  # real signature unknown; restored from __doc__
        """ QXmlLexicalHandler.endDTD() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endEntity(self, QString):
        """ QXmlLexicalHandler.endEntity(QString) -> bool """
        return False

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlLexicalHandler.errorString() -> QString """
        pass

    def startCDATA(self):  # real signature unknown; restored from __doc__
        """ QXmlLexicalHandler.startCDATA() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startDTD(self, QString, QString_1, QString_2):
        """ QXmlLexicalHandler.startDTD(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startEntity(self, QString):
        """ QXmlLexicalHandler.startEntity(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlLexicalHandler=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlDefaultHandler(QXmlContentHandler, QXmlErrorHandler, QXmlDTDHandler, QXmlEntityResolver, QXmlLexicalHandler, QXmlDeclHandler):

    """ QXmlDefaultHandler() """
    # real signature unknown; restored from __doc__

    def attributeDecl(self, QString, QString_1, QString_2, QString_3, QString_4):
        """ QXmlDefaultHandler.attributeDecl(QString, QString, QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def characters(self, QString):
        """ QXmlDefaultHandler.characters(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def comment(self, QString):
        """ QXmlDefaultHandler.comment(QString) -> bool """
        return False

    def endCDATA(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.endCDATA() -> bool """
        return False

    def endDocument(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.endDocument() -> bool """
        return False

    def endDTD(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.endDTD() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endElement(self, QString, QString_1, QString_2):
        """ QXmlDefaultHandler.endElement(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endEntity(self, QString):
        """ QXmlDefaultHandler.endEntity(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def endPrefixMapping(self, QString):
        """ QXmlDefaultHandler.endPrefixMapping(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def error(self, QXmlParseException):
        """ QXmlDefaultHandler.error(QXmlParseException) -> bool """
        return False

    def errorString(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.errorString() -> QString """
        pass

    # real signature unknown; restored from __doc__
    def externalEntityDecl(self, QString, QString_1, QString_2):
        """ QXmlDefaultHandler.externalEntityDecl(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def fatalError(self, QXmlParseException):
        """ QXmlDefaultHandler.fatalError(QXmlParseException) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def ignorableWhitespace(self, QString):
        """ QXmlDefaultHandler.ignorableWhitespace(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def internalEntityDecl(self, QString, QString_1):
        """ QXmlDefaultHandler.internalEntityDecl(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def notationDecl(self, QString, QString_1, QString_2):
        """ QXmlDefaultHandler.notationDecl(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def processingInstruction(self, QString, QString_1):
        """ QXmlDefaultHandler.processingInstruction(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def resolveEntity(self, QString, QString_1):
        """ QXmlDefaultHandler.resolveEntity(QString, QString) -> (bool, QXmlInputSource) """
        pass

    # real signature unknown; restored from __doc__
    def setDocumentLocator(self, QXmlLocator):
        """ QXmlDefaultHandler.setDocumentLocator(QXmlLocator) """
        pass

    # real signature unknown; restored from __doc__
    def skippedEntity(self, QString):
        """ QXmlDefaultHandler.skippedEntity(QString) -> bool """
        return False

    def startCDATA(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.startCDATA() -> bool """
        return False

    def startDocument(self):  # real signature unknown; restored from __doc__
        """ QXmlDefaultHandler.startDocument() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startDTD(self, QString, QString_1, QString_2):
        """ QXmlDefaultHandler.startDTD(QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startElement(self, QString, QString_1, QString_2, QXmlAttributes):
        """ QXmlDefaultHandler.startElement(QString, QString, QString, QXmlAttributes) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startEntity(self, QString):
        """ QXmlDefaultHandler.startEntity(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def startPrefixMapping(self, QString, QString_1):
        """ QXmlDefaultHandler.startPrefixMapping(QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def unparsedEntityDecl(self, QString, QString_1, QString_2, QString_3):
        """ QXmlDefaultHandler.unparsedEntityDecl(QString, QString, QString, QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def warning(self, QXmlParseException):
        """ QXmlDefaultHandler.warning(QXmlParseException) -> bool """
        return False

    def __init__(self):  # real signature unknown; restored from __doc__
        pass


class QXmlInputSource():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlInputSource()
    QXmlInputSource(QIODevice)
    QXmlInputSource(QXmlInputSource)
    """

    def data(self):  # real signature unknown; restored from __doc__
        """ QXmlInputSource.data() -> QString """
        pass

    def fetchData(self):  # real signature unknown; restored from __doc__
        """ QXmlInputSource.fetchData() """
        pass

    # real signature unknown; restored from __doc__
    def fromRawData(self, QByteArray, bool_beginning=False):
        """ QXmlInputSource.fromRawData(QByteArray, bool beginning=False) -> QString """
        pass

    def next(self):  # real signature unknown; restored from __doc__
        """ QXmlInputSource.next() -> QChar """
        pass

    def reset(self):  # real signature unknown; restored from __doc__
        """ QXmlInputSource.reset() """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def setData(self, *__args):
        """
        QXmlInputSource.setData(QString)
        QXmlInputSource.setData(QByteArray)
        """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, *__args):
        pass

    __weakref__ = property(lambda self: object())  # default

    EndOfData = 65534L
    EndOfDocument = 65535L


class QXmlLocator():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlLocator()
    QXmlLocator(QXmlLocator)
    """

    def columnNumber(self):  # real signature unknown; restored from __doc__
        """ QXmlLocator.columnNumber() -> int """
        return 0

    def lineNumber(self):  # real signature unknown; restored from __doc__
        """ QXmlLocator.lineNumber() -> int """
        return 0

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlLocator=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlNamespaceSupport():  # skipped bases: <type 'sip.simplewrapper'>

    """ QXmlNamespaceSupport() """

    def popContext(self):  # real signature unknown; restored from __doc__
        """ QXmlNamespaceSupport.popContext() """
        pass

    def prefix(self, QString):  # real signature unknown; restored from __doc__
        """ QXmlNamespaceSupport.prefix(QString) -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def prefixes(self, QString=None):
        """
        QXmlNamespaceSupport.prefixes() -> QStringList
        QXmlNamespaceSupport.prefixes(QString) -> QStringList
        """
        pass

    # real signature unknown; restored from __doc__
    def processName(self, QString, bool, QString_1, QString_2):
        """ QXmlNamespaceSupport.processName(QString, bool, QString, QString) """
        pass

    def pushContext(self):  # real signature unknown; restored from __doc__
        """ QXmlNamespaceSupport.pushContext() """
        pass

    def reset(self):  # real signature unknown; restored from __doc__
        """ QXmlNamespaceSupport.reset() """
        pass

    # real signature unknown; restored from __doc__
    def setPrefix(self, QString, QString_1):
        """ QXmlNamespaceSupport.setPrefix(QString, QString) """
        pass

    # real signature unknown; restored from __doc__
    def splitName(self, QString, QString_1, QString_2):
        """ QXmlNamespaceSupport.splitName(QString, QString, QString) """
        pass

    def uri(self, QString):  # real signature unknown; restored from __doc__
        """ QXmlNamespaceSupport.uri(QString) -> QString """
        pass

    def __init__(self):  # real signature unknown; restored from __doc__
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlParseException():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlParseException(QString name=QString(), int column=-1, int line=-1, QString publicId=QString(), QString systemId=QString())
    QXmlParseException(QXmlParseException)
    """

    def columnNumber(self):  # real signature unknown; restored from __doc__
        """ QXmlParseException.columnNumber() -> int """
        return 0

    def lineNumber(self):  # real signature unknown; restored from __doc__
        """ QXmlParseException.lineNumber() -> int """
        return 0

    def message(self):  # real signature unknown; restored from __doc__
        """ QXmlParseException.message() -> QString """
        pass

    def publicId(self):  # real signature unknown; restored from __doc__
        """ QXmlParseException.publicId() -> QString """
        pass

    def systemId(self):  # real signature unknown; restored from __doc__
        """ QXmlParseException.systemId() -> QString """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, *__args):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlReader():  # skipped bases: <type 'sip.simplewrapper'>

    """
    QXmlReader()
    QXmlReader(QXmlReader)
    """

    def contentHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.contentHandler() -> QXmlContentHandler """
        return QXmlContentHandler

    def declHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.declHandler() -> QXmlDeclHandler """
        return QXmlDeclHandler

    def DTDHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.DTDHandler() -> QXmlDTDHandler """
        return QXmlDTDHandler

    def entityResolver(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.entityResolver() -> QXmlEntityResolver """
        return QXmlEntityResolver

    def errorHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.errorHandler() -> QXmlErrorHandler """
        return QXmlErrorHandler

    # real signature unknown; restored from __doc__
    def feature(self, QString):
        """ QXmlReader.feature(QString) -> (bool, bool) """
        pass

    # real signature unknown; restored from __doc__
    def hasFeature(self, QString):
        """ QXmlReader.hasFeature(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def hasProperty(self, QString):
        """ QXmlReader.hasProperty(QString) -> bool """
        return False

    def lexicalHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlReader.lexicalHandler() -> QXmlLexicalHandler """
        return QXmlLexicalHandler

    # real signature unknown; restored from __doc__ with multiple overloads
    def parse(self, QXmlInputSource):
        """
        QXmlReader.parse(QXmlInputSource) -> bool
        QXmlReader.parse(QXmlInputSource) -> bool
        """
        return False

    # real signature unknown; restored from __doc__
    def property(self, QString):
        """ QXmlReader.property(QString) -> (sip.voidptr, bool) """
        pass

    # real signature unknown; restored from __doc__
    def setContentHandler(self, QXmlContentHandler):
        """ QXmlReader.setContentHandler(QXmlContentHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setDeclHandler(self, QXmlDeclHandler):
        """ QXmlReader.setDeclHandler(QXmlDeclHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setDTDHandler(self, QXmlDTDHandler):
        """ QXmlReader.setDTDHandler(QXmlDTDHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setEntityResolver(self, QXmlEntityResolver):
        """ QXmlReader.setEntityResolver(QXmlEntityResolver) """
        pass

    # real signature unknown; restored from __doc__
    def setErrorHandler(self, QXmlErrorHandler):
        """ QXmlReader.setErrorHandler(QXmlErrorHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setFeature(self, QString, bool):
        """ QXmlReader.setFeature(QString, bool) """
        pass

    # real signature unknown; restored from __doc__
    def setLexicalHandler(self, QXmlLexicalHandler):
        """ QXmlReader.setLexicalHandler(QXmlLexicalHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setProperty(self, QString, sip_voidptr):
        """ QXmlReader.setProperty(QString, sip.voidptr) """
        pass

    # real signature unknown; restored from __doc__ with multiple overloads
    def __init__(self, QXmlReader=None):
        pass

    __weakref__ = property(lambda self: object())  # default


class QXmlSimpleReader(QXmlReader):

    """ QXmlSimpleReader() """

    def contentHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.contentHandler() -> QXmlContentHandler """
        return QXmlContentHandler

    def declHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.declHandler() -> QXmlDeclHandler """
        return QXmlDeclHandler

    def DTDHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.DTDHandler() -> QXmlDTDHandler """
        return QXmlDTDHandler

    def entityResolver(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.entityResolver() -> QXmlEntityResolver """
        return QXmlEntityResolver

    def errorHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.errorHandler() -> QXmlErrorHandler """
        return QXmlErrorHandler

    # real signature unknown; restored from __doc__
    def feature(self, QString):
        """ QXmlSimpleReader.feature(QString) -> (bool, bool) """
        pass

    # real signature unknown; restored from __doc__
    def hasFeature(self, QString):
        """ QXmlSimpleReader.hasFeature(QString) -> bool """
        return False

    # real signature unknown; restored from __doc__
    def hasProperty(self, QString):
        """ QXmlSimpleReader.hasProperty(QString) -> bool """
        return False

    def lexicalHandler(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.lexicalHandler() -> QXmlLexicalHandler """
        return QXmlLexicalHandler

    # real signature unknown; restored from __doc__ with multiple overloads
    def parse(self, QXmlInputSource, bool=None):
        """
        QXmlSimpleReader.parse(QXmlInputSource) -> bool
        QXmlSimpleReader.parse(QXmlInputSource, bool) -> bool
        """
        return False

    def parseContinue(self):  # real signature unknown; restored from __doc__
        """ QXmlSimpleReader.parseContinue() -> bool """
        return False

    # real signature unknown; restored from __doc__
    def property(self, QString):
        """ QXmlSimpleReader.property(QString) -> (sip.voidptr, bool) """
        pass

    # real signature unknown; restored from __doc__
    def setContentHandler(self, QXmlContentHandler):
        """ QXmlSimpleReader.setContentHandler(QXmlContentHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setDeclHandler(self, QXmlDeclHandler):
        """ QXmlSimpleReader.setDeclHandler(QXmlDeclHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setDTDHandler(self, QXmlDTDHandler):
        """ QXmlSimpleReader.setDTDHandler(QXmlDTDHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setEntityResolver(self, QXmlEntityResolver):
        """ QXmlSimpleReader.setEntityResolver(QXmlEntityResolver) """
        pass

    # real signature unknown; restored from __doc__
    def setErrorHandler(self, QXmlErrorHandler):
        """ QXmlSimpleReader.setErrorHandler(QXmlErrorHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setFeature(self, QString, bool):
        """ QXmlSimpleReader.setFeature(QString, bool) """
        pass

    # real signature unknown; restored from __doc__
    def setLexicalHandler(self, QXmlLexicalHandler):
        """ QXmlSimpleReader.setLexicalHandler(QXmlLexicalHandler) """
        pass

    # real signature unknown; restored from __doc__
    def setProperty(self, QString, sip_voidptr):
        """ QXmlSimpleReader.setProperty(QString, sip.voidptr) """
        pass

    def __init__(self):  # real signature unknown; restored from __doc__
        pass
