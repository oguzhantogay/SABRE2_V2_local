# encoding: utf-8
# module PyKDE4.nepomuk
# from /usr/lib/python2.7/dist-packages/PyKDE4/nepomuk.so by generator 1.96
# no doc

# imports
import PyQt4.QtGui as __PyQt4_QtGui


# no functions
# classes

class KTagCloudWidget(__PyQt4_QtGui.QWidget):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def addTag(self, *args, **kwargs):  # real signature unknown
        pass

    def addTags(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def clear(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setMaxFontSize(self, *args, **kwargs):  # real signature unknown
        pass

    def setMinFontSize(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tagClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def tagWeight(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class KTagDisplayWidget(__PyQt4_QtGui.QWidget):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def addTag(self, *args, **kwargs):  # real signature unknown
        pass

    def addTags(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def clear(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setTags(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def tagClicked(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass


class Nepomuk():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def ErrorCode(self, *args, **kwargs):  # real signature unknown
        pass

    def errorString(self, *args, **kwargs):  # real signature unknown
        pass

    def extractNamespace(self, *args, **kwargs):  # real signature unknown
        pass

    def File(self, *args, **kwargs):  # real signature unknown
        pass

    def MassUpdateJob(self, *args, **kwargs):  # real signature unknown
        pass

    def qHash(self, *args, **kwargs):  # real signature unknown
        pass

    def Query(self, *args, **kwargs):  # real signature unknown
        pass

    def RDFLiteralToValue(self, *args, **kwargs):  # real signature unknown
        pass

    def Resource(self, *args, **kwargs):  # real signature unknown
        pass

    def ResourceManager(self, *args, **kwargs):  # real signature unknown
        pass

    def Service(self, *args, **kwargs):  # real signature unknown
        pass

    def Tag(self, *args, **kwargs):  # real signature unknown
        pass

    def TagCloud(self, *args, **kwargs):  # real signature unknown
        pass

    def TagWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def Thing(self, *args, **kwargs):  # real signature unknown
        pass

    def Types(self, *args, **kwargs):  # real signature unknown
        pass

    def valuesToRDFNodes(self, *args, **kwargs):  # real signature unknown
        pass

    def valueToRDFNode(self, *args, **kwargs):  # real signature unknown
        pass

    def Variant(self, *args, **kwargs):  # real signature unknown
        pass

    def Vocabulary(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    CommunicationError = 1
    InvalidType = 2
    NoError = 0
    UnknownError = 3
