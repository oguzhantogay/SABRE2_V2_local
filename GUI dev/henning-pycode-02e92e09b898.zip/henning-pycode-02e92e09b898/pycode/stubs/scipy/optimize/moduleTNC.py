# encoding: utf-8
# module scipy.optimize.moduleTNC
# from /usr/lib/python2.7/dist-packages/scipy/optimize/moduleTNC.so by generator 1.96
# no doc
# no imports

# functions


def minimize(*args, **kwargs):  # real signature unknown
    pass


# no classes
