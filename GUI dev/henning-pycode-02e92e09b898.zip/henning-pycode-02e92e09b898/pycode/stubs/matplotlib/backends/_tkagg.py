# encoding: utf-8
# module matplotlib.backends._tkagg
# from /usr/lib/pymodules/python2.7/matplotlib/backends/_tkagg.so by generator 1.96
# no doc
# no imports

# functions


def tkinit(*args, **kwargs):  # real signature unknown
    pass


def _pyobj_addr(*args, **kwargs):  # real signature unknown
    pass


# no classes
