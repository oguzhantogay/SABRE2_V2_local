# encoding: utf-8
# module scipy.ndimage._nd_image
# from /usr/lib/python2.7/dist-packages/scipy/ndimage/_nd_image.so by generator 1.96
# no doc
# no imports

# functions


def binary_erosion(*args, **kwargs):  # real signature unknown
    pass


def binary_erosion2(*args, **kwargs):  # real signature unknown
    pass


def correlate(*args, **kwargs):  # real signature unknown
    pass


def correlate1d(*args, **kwargs):  # real signature unknown
    pass


def distance_transform_bf(*args, **kwargs):  # real signature unknown
    pass


def distance_transform_op(*args, **kwargs):  # real signature unknown
    pass


def euclidean_feature_transform(*args, **kwargs):  # real signature unknown
    pass


def find_objects(*args, **kwargs):  # real signature unknown
    pass


def fourier_filter(*args, **kwargs):  # real signature unknown
    pass


def fourier_shift(*args, **kwargs):  # real signature unknown
    pass


def generic_filter(*args, **kwargs):  # real signature unknown
    pass


def generic_filter1d(*args, **kwargs):  # real signature unknown
    pass


def geometric_transform(*args, **kwargs):  # real signature unknown
    pass


def label(*args, **kwargs):  # real signature unknown
    pass


def min_or_max_filter(*args, **kwargs):  # real signature unknown
    pass


def min_or_max_filter1d(*args, **kwargs):  # real signature unknown
    pass


def rank_filter(*args, **kwargs):  # real signature unknown
    pass


def spline_filter1d(*args, **kwargs):  # real signature unknown
    pass


def uniform_filter1d(*args, **kwargs):  # real signature unknown
    pass


def watershed_ift(*args, **kwargs):  # real signature unknown
    pass


def zoom_shift(*args, **kwargs):  # real signature unknown
    pass


# no classes
