# encoding: utf-8
# module matplotlib.backends._backend_gdk
# from /usr/lib/pymodules/python2.7/matplotlib/backends/_backend_gdk.so by generator 1.96
# no doc
# no imports

# functions


def pixbuf_get_pixels_array(*args, **kwargs):  # real signature unknown
    pass


# no classes
