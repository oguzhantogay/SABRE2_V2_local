# encoding: utf-8
# module numpy.core.scalarmath
# from /usr/lib/pymodules/python2.7/numpy/core/scalarmath.so by generator 1.96
# no doc
# no imports

# functions


def alter_pythonmath(*args, **kwargs):  # real signature unknown
    """  """
    pass


def restore_pythonmath(*args, **kwargs):  # real signature unknown
    """  """
    pass


def use_pythonmath(*args, **kwargs):  # real signature unknown
    """  """
    pass


def use_scalarmath(*args, **kwargs):  # real signature unknown
    """  """
    pass


# no classes
