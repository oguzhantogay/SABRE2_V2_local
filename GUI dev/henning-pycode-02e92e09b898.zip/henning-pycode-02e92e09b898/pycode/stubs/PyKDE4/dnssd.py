# encoding: utf-8
# module PyKDE4.dnssd
# from /usr/lib/python2.7/dist-packages/PyKDE4/dnssd.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class DNSSD():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def DomainBrowser(self, *args, **kwargs):  # real signature unknown
        pass

    def DomainModel(self, *args, **kwargs):  # real signature unknown
        pass

    def PublicService(self, *args, **kwargs):  # real signature unknown
        pass

    def RemoteService(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceBase(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceBrowser(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceModel(self, *args, **kwargs):  # real signature unknown
        pass

    def ServiceTypeBrowser(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
