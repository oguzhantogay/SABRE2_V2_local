# encoding: utf-8
# module scipy.optimize._cobyla
# from /usr/lib/python2.7/dist-packages/scipy/optimize/_cobyla.so by
# generator 1.96
"""
This module '_cobyla' is auto-generated with f2py (version:1).
Functions:
  x = minimize(calcfc,m,x,rhobeg,rhoend,iprint=1,maxfun=100,calcfc_extra_args=())
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

minimize = None  # (!) real value is ''
