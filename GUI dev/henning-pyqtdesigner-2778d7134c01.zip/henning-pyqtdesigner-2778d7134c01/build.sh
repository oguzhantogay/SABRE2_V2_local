#!/bin/sh
cd pyqtdesigner/EmbeddedDesigner
qmake
make

