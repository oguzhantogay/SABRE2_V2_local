#!/usr/bin/env python
# module: 'marshal'


def dump(*x):
    return


def dumps(*x):
    return


def load(*x):
    return


def loads(*x):
    return

version = 0
