function SABRE2ALinMultiFun(pn_panel,pt_title_name,fim_infor_name,vdum_panel,...
   vdum_type_subpanel,vdum_type_name,v1um_p1_text,v1um_p2_text,v1um_p3_text,...
   v1um_p4_text,v1um_p5_text,v1um_p1_edit,v1um_p2_edit,v1um_p3_edit,v1um_p4_edit,...
   v1um_p5_edit,ptable_type_subpanel,ptable_type_text,ptable_node_subpanel,...
   ptable_node_text,ptable_node,ptable_wsection_text,ptable_wsection_edit,...
   ptable_set,ptable_wsname_edit,ptable_seg_subpanel,ptable_seg_text,ptable_seg,...
   ptable_brac_subpanel,ptable_brac_text,ptable_addbracing,ptable_remove_edit,...
   ptable_removebracing,ptable_app_subpanel,ptable_apply,ptable_cancel,am3_type_text,...
   anal_subpanel,anal_text,am3_eq_text,am_jval_text,am3_jval_buttongroup,...
   am3_jval_on_radiobutton,am3_jval_off_radiobutton,aa3_apply,res_subpanel,...
   res_text,recba_gamma_text,recba_scale_text,recba_mode_text,recba_gamma_edit,...
   recba_Scale_edit,recba_mode_edit,recba_undef3d_text,recba_buttongroup,...
   recba_on_radiobutton,recba_off_radiobutton,ar3_apply,am4_type_text,am4_eq_text,...
   am_cv_text,am_cv_buttongroup,am_cv_on_radiobutton,am_cv_off_radiobutton,...
   am_jeong_text,am_brent_text,am_jeong_edit,am_brent_edit,aa4_apply,...
   reicba_gamma_edit,reicba_Scale_edit,reicba_mode_edit,recba_tau_diagram,...
   ar4_apply,am6_type_text,am6_eq_text,am_da_text,am6_da_buttongroup,...
   am6_da_on_radiobutton,am6_da_off_radiobutton,aa6_apply,renicba_gamma_edit,...
   renicba_Scale_edit,renicba_mode_edit,ar6_apply,auto_type_text,auto_modelname_text,...
   auto_modelnum_text,auto_modelname_edit,auto_modelnum_edit,auto_lin_apply,auto_nonlin_apply)

% Developed by Woo Yong Jeong.
% Date : 12/01/2012.
% ************************************************************************
% *****************              VISIBLE              ********************
% ************************************************************************
set(pn_panel,'Visible','on')
% *************** Title
set(pt_title_name,'Visible','off')
% *************** About
set(fim_infor_name,'Visible','off')

% *************** Visible off for Design Resource S
set([vdum_panel,vdum_type_subpanel],'Visible','off')
set([vdum_type_name,v1um_p1_text,v1um_p2_text,v1um_p3_text,v1um_p4_text,v1um_p5_text],'Visible','off') 
set([v1um_p1_edit,v1um_p2_edit,v1um_p3_edit,v1um_p4_edit,v1um_p5_edit],'Visible','off')
% *************** Visible off for Design Resource E

% *************** Visible off for Modeling S
% *** sub panel1
set(ptable_type_subpanel,'Visible','on')
set(ptable_type_text,'Visible','off')
% *** sub panel2
set(ptable_node_subpanel,'Visible','off')
set(ptable_node_text,'Visible','off');
set(ptable_node,'Visible','off');
set([ptable_wsection_text,ptable_wsection_edit,ptable_set,ptable_wsname_edit],'Visible','off');
% *** sub panel3
set(ptable_seg_subpanel,'Visible','off');
set(ptable_seg_text,'Visible','off');
set(ptable_seg,'Visible','off')
% *** sub panel4
set(ptable_brac_subpanel,'Visible','off');
set(ptable_brac_text,'Visible','off');
set(ptable_addbracing,'Visible','off');
set(ptable_remove_edit,'Visible','off');
set(ptable_removebracing,'Visible','off');
% *** sub panel5
set(ptable_app_subpanel,'Visible','off');
set([ptable_apply,ptable_cancel],'Visible','off'); 
% *************** Visible off for Modeling E


% *************** Visible off for Elastic Linear Buckling S
% *** sub panel1
set(am3_type_text,'Visible','off')
% *** sub panel2
set(anal_subpanel,'Visible','on');
set([anal_text,am3_eq_text],'Visible','off');
set([am_jval_text,am3_jval_buttongroup,am3_jval_on_radiobutton,am3_jval_off_radiobutton],'Visible','off');
set(aa3_apply,'Visible','off');
% *** sub panel3
set(res_subpanel,'Visible','off');
set([res_text,recba_gamma_text,recba_scale_text,recba_mode_text],'Visible','off');
set([recba_gamma_edit,recba_Scale_edit,recba_mode_edit],'Visible','off');
set(recba_undef3d_text,'Visible','off');
set([recba_buttongroup,recba_on_radiobutton,recba_off_radiobutton],'Visible','off');
set(ar3_apply,'Visible','off');  
% *************** Visible off for Elastic Linear Buckling E


% *************** Visible off for Inelastic Linear Buckling S
% *** sub panel1
set(am4_type_text,'Visible','off')
% *** sub panel2
set([am4_eq_text,am_cv_text],'Visible','off');
set([am_cv_buttongroup,am_cv_on_radiobutton,am_cv_off_radiobutton],'Visible','on');
set([am_jeong_text,am_brent_text],'Visible','on');
set([am_jeong_edit,am_brent_edit],'Visible','on');
set(aa4_apply,'Visible','off');
% *** sub panel3
set([reicba_gamma_edit,reicba_Scale_edit,reicba_mode_edit],'Visible','off');
set(recba_tau_diagram,'Visible','off');
set(ar4_apply,'Visible','off');
% *************** Visible off for Inelastic Linear Buckling E

% *************** Visible off for Inelastic Nonlinear Buckling S
% *** sub panel1
set(am6_type_text,'Visible','off')
% *** sub panel2
set(am6_eq_text,'Visible','off');
set([am_da_text,am6_da_buttongroup,am6_da_on_radiobutton,am6_da_off_radiobutton],'Visible','off');
set(aa6_apply,'Visible','off');
% *** sub panel3
set([renicba_gamma_edit,renicba_Scale_edit,renicba_mode_edit,ar6_apply],'Visible','off');
% *************** Visible off for Inelastic Nonlinear Buckling E

% *************** Visible off for Batch Mode S
% *** sub panel1
set(auto_type_text,'Visible','on')
% *** sub panel2
set([auto_modelname_text,auto_modelnum_text,auto_modelname_edit,auto_modelnum_edit],'Visible','on');
set(auto_lin_apply,'Visible','on');
set(auto_nonlin_apply,'Visible','off');
% *************** Visible off for Batch Mode E

end