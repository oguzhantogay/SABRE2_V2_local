# encoding: utf-8
# module scipy.optimize._nnls
# from /usr/lib/python2.7/dist-packages/scipy/optimize/_nnls.so by
# generator 1.96
"""
This module '_nnls' is auto-generated with f2py (version:1).
Functions:
  x,rnorm,mode = nnls(a,m,n,b,w,zz,index_bn,mda=shape(a,0),overwrite_a=0,overwrite_b=0)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

nnls = None  # (!) real value is ''
