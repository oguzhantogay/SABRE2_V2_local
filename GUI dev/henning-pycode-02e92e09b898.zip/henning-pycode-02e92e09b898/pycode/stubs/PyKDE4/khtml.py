# encoding: utf-8
# module PyKDE4.khtml
# from /usr/lib/python2.7/dist-packages/PyKDE4/khtml.so by generator 1.96
# no doc

# imports
import PyKDE4.kparts as __PyKDE4_kparts
import PyQt4.QtGui as __PyQt4_QtGui


# no functions
# classes

class DOM():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def AbstractView(self, *args, **kwargs):  # real signature unknown
        pass

    def Attr(self, *args, **kwargs):  # real signature unknown
        pass

    def CDATASection(self, *args, **kwargs):  # real signature unknown
        pass

    def CharacterData(self, *args, **kwargs):  # real signature unknown
        pass

    def Comment(self, *args, **kwargs):  # real signature unknown
        pass

    def Counter(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSCharsetRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSException(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSFontFaceRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSImportRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSMediaRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSNamespaceRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSPageRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSPrimitiveValue(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSRuleList(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSStyleDeclaration(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSStyleRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSStyleSheet(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSUnknownRule(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSValue(self, *args, **kwargs):  # real signature unknown
        pass

    def CSSValueList(self, *args, **kwargs):  # real signature unknown
        pass

    def CustomNodeFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def Document(self, *args, **kwargs):  # real signature unknown
        pass

    def DocumentFragment(self, *args, **kwargs):  # real signature unknown
        pass

    def DocumentStyle(self, *args, **kwargs):  # real signature unknown
        pass

    def DocumentType(self, *args, **kwargs):  # real signature unknown
        pass

    def DOMException(self, *args, **kwargs):  # real signature unknown
        pass

    def DOMImplementation(self, *args, **kwargs):  # real signature unknown
        pass

    def DomShared(self, *args, **kwargs):  # real signature unknown
        pass

    def DOMString(self, *args, **kwargs):  # real signature unknown
        pass

    def Element(self, *args, **kwargs):  # real signature unknown
        pass

    def Entity(self, *args, **kwargs):  # real signature unknown
        pass

    def EntityReference(self, *args, **kwargs):  # real signature unknown
        pass

    def Event(self, *args, **kwargs):  # real signature unknown
        pass

    def EventException(self, *args, **kwargs):  # real signature unknown
        pass

    def EventListener(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLAnchorElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLAppletElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLAreaElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLBaseElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLBaseFontElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLBlockquoteElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLBodyElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLBRElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLButtonElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLCollection(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLDirectoryElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLDivElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLDListElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLDocument(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLFieldSetElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLFontElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLFormElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLFrameElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLFrameSetElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLHeadElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLHeadingElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLHRElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLHtmlElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLIFrameElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLImageElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLInputElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLIsIndexElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLLabelElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLLayerElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLLegendElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLLIElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLLinkElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLMapElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLMenuElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLMetaElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLModElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLObjectElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLOListElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLOptGroupElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLOptionElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLParagraphElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLParamElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLPreElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLQuoteElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLScriptElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLSelectElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLStyleElement(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def HTMLTableCaptionElement(self, *args, **kwargs):
        pass

    def HTMLTableCellElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLTableColElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLTableElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLTableRowElement(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def HTMLTableSectionElement(self, *args, **kwargs):
        pass

    def HTMLTextAreaElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLTitleElement(self, *args, **kwargs):  # real signature unknown
        pass

    def HTMLUListElement(self, *args, **kwargs):  # real signature unknown
        pass

    def KeyboardEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def LinkStyle(self, *args, **kwargs):  # real signature unknown
        pass

    def MediaList(self, *args, **kwargs):  # real signature unknown
        pass

    def MouseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def MutationEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def NamedNodeMap(self, *args, **kwargs):  # real signature unknown
        pass

    def Node(self, *args, **kwargs):  # real signature unknown
        pass

    def NodeFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def NodeIterator(self, *args, **kwargs):  # real signature unknown
        pass

    def NodeList(self, *args, **kwargs):  # real signature unknown
        pass

    def Notation(self, *args, **kwargs):  # real signature unknown
        pass

    def ProcessingInstruction(self, *args, **kwargs):  # real signature unknown
        pass

    def Range(self, *args, **kwargs):  # real signature unknown
        pass

    def RangeException(self, *args, **kwargs):  # real signature unknown
        pass

    def Rect(self, *args, **kwargs):  # real signature unknown
        pass

    def RGBColor(self, *args, **kwargs):  # real signature unknown
        pass

    def strcasecmp(self, *args, **kwargs):  # real signature unknown
        pass

    def strcmp(self, *args, **kwargs):  # real signature unknown
        pass

    def StyleSheet(self, *args, **kwargs):  # real signature unknown
        pass

    def StyleSheetList(self, *args, **kwargs):  # real signature unknown
        pass

    def Text(self, *args, **kwargs):  # real signature unknown
        pass

    def TextEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def TreeWalker(self, *args, **kwargs):  # real signature unknown
        pass

    def UIEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default


class KHTMLPart(__PyKDE4_kparts.ReadOnlyPart):
    # no doc

    def abortLoad(self, *args, **kwargs):  # real signature unknown
        pass

    def activeNode(self, *args, **kwargs):  # real signature unknown
        pass

    def autoloadImages(self, *args, **kwargs):  # real signature unknown
        pass

    def backgroundURL(self, *args, **kwargs):  # real signature unknown
        pass

    def baseURL(self, *args, **kwargs):  # real signature unknown
        pass

    def begin(self, *args, **kwargs):  # real signature unknown
        pass

    def browserExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def browserHostExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def CaretDisplayPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def caretDisplayPolicyNonFocused(self, *args, **kwargs):
        pass

    def caretPositionChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def closeUrl(self, *args, **kwargs):  # real signature unknown
        pass

    def completeURL(self, *args, **kwargs):  # real signature unknown
        pass

    def configurationChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def createPart(self, *args, **kwargs):  # real signature unknown
        pass

    def currentFrame(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def dndEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def dnsPrefetch(self, *args, **kwargs):  # real signature unknown
        pass

    def DNSPrefetch(self, *args, **kwargs):  # real signature unknown
        pass

    def docCreated(self, *args, **kwargs):  # real signature unknown
        pass

    def doCloseStream(self, *args, **kwargs):  # real signature unknown
        pass

    def document(self, *args, **kwargs):  # real signature unknown
        pass

    def documentSource(self, *args, **kwargs):  # real signature unknown
        pass

    def doOpenStream(self, *args, **kwargs):  # real signature unknown
        pass

    def doWriteStream(self, *args, **kwargs):  # real signature unknown
        pass

    def encoding(self, *args, **kwargs):  # real signature unknown
        pass

    def end(self, *args, **kwargs):  # real signature unknown
        pass

    def executeScript(self, *args, **kwargs):  # real signature unknown
        pass

    def findFrame(self, *args, **kwargs):  # real signature unknown
        pass

    def findFramePart(self, *args, **kwargs):  # real signature unknown
        pass

    def FindOptions(self, *args, **kwargs):  # real signature unknown
        pass

    def findText(self, *args, **kwargs):  # real signature unknown
        pass

    def findTextBegin(self, *args, **kwargs):  # real signature unknown
        pass

    def findTextNext(self, *args, **kwargs):  # real signature unknown
        pass

    def fontScaleFactor(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def forcePermitLocalImages(self, *args, **kwargs):
        pass

    def formNotification(self, *args, **kwargs):  # real signature unknown
        pass

    def FormNotification(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def formSubmitNotification(self, *args, **kwargs):
        pass

    def frameExists(self, *args, **kwargs):  # real signature unknown
        pass

    def frameNames(self, *args, **kwargs):  # real signature unknown
        pass

    def frames(self, *args, **kwargs):  # real signature unknown
        pass

    def gotoAnchor(self, *args, **kwargs):  # real signature unknown
        pass

    def guiActivateEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def GUIProfile(self, *args, **kwargs):  # real signature unknown
        pass

    def hasSelection(self, *args, **kwargs):  # real signature unknown
        pass

    def hide(self, *args, **kwargs):  # real signature unknown
        pass

    def hostContainer(self, *args, **kwargs):  # real signature unknown
        pass

    def htmlDocument(self, *args, **kwargs):  # real signature unknown
        pass

    def htmlError(self, *args, **kwargs):  # real signature unknown
        pass

    def inProgress(self, *args, **kwargs):  # real signature unknown
        pass

    def isCaretMode(self, *args, **kwargs):  # real signature unknown
        pass

    def isEditable(self, *args, **kwargs):  # real signature unknown
        pass

    def isLocalFileTemporary(self, *args, **kwargs):  # real signature unknown
        pass

    def isModified(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def isPointInsideSelection(self, *args, **kwargs):
        pass

    def javaEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def jScriptEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def jsDefaultStatusBarText(self, *args, **kwargs):
        pass

    def jsStatusBarText(self, *args, **kwargs):  # real signature unknown
        pass

    def lastModified(self, *args, **kwargs):  # real signature unknown
        pass

    def loadPlugins(self, *args, **kwargs):  # real signature unknown
        pass

    def loadStandardsXmlFile(self, *args, **kwargs):  # real signature unknown
        pass

    def localFilePath(self, *args, **kwargs):  # real signature unknown
        pass

    def mayPrefetchHostname(self, *args, **kwargs):  # real signature unknown
        pass

    def metaRefreshEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def nextAnchor(self, *args, **kwargs):  # real signature unknown
        pass

    def nodeActivated(self, *args, **kwargs):  # real signature unknown
        pass

    def nodeUnderMouse(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def nonSharedNodeUnderMouse(self, *args, **kwargs):
        pass

    def onlyLocalReferences(self, *args, **kwargs):  # real signature unknown
        pass

    def onURL(self, *args, **kwargs):  # real signature unknown
        pass

    def openFile(self, *args, **kwargs):  # real signature unknown
        pass

    def openUrl(self, *args, **kwargs):  # real signature unknown
        pass

    def pageReferrer(self, *args, **kwargs):  # real signature unknown
        pass

    def PageSecurity(self, *args, **kwargs):  # real signature unknown
        pass

    def paint(self, *args, **kwargs):  # real signature unknown
        pass

    def parentPart(self, *args, **kwargs):  # real signature unknown
        pass

    def partActivateEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def partManager(self, *args, **kwargs):  # real signature unknown
        pass

    def partSelectEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def pluginPageQuestionAsked(self, *args, **kwargs):
        pass

    def pluginsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def popupMenu(self, *args, **kwargs):  # real signature unknown
        pass

    def preloadScript(self, *args, **kwargs):  # real signature unknown
        pass

    def preloadStyleSheet(self, *args, **kwargs):  # real signature unknown
        pass

    def prevAnchor(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def referrer(self, *args, **kwargs):  # real signature unknown
        pass

    def restored(self, *args, **kwargs):  # real signature unknown
        pass

    def restoreState(self, *args, **kwargs):  # real signature unknown
        pass

    def saveState(self, *args, **kwargs):  # real signature unknown
        pass

    def scheduleRedirection(self, *args, **kwargs):  # real signature unknown
        pass

    def selectAll(self, *args, **kwargs):  # real signature unknown
        pass

    def selectedText(self, *args, **kwargs):  # real signature unknown
        pass

    def selectedTextAsHTML(self, *args, **kwargs):  # real signature unknown
        pass

    def selection(self, *args, **kwargs):  # real signature unknown
        pass

    def selectionChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setActiveNode(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setAlwaysHonourDoctype(self, *args, **kwargs):
        pass

    def setAutoloadImages(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setCaretDisplayPolicyNonFocused(self, *args, **kwargs):
        pass

    def setCaretMode(self, *args, **kwargs):  # real signature unknown
        pass

    def setCaretPosition(self, *args, **kwargs):  # real signature unknown
        pass

    def setCaretVisible(self, *args, **kwargs):  # real signature unknown
        pass

    def setComponentData(self, *args, **kwargs):  # real signature unknown
        pass

    def setDNDEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def setDNSPrefetch(self, *args, **kwargs):  # real signature unknown
        pass

    def setDOMDocument(self, *args, **kwargs):  # real signature unknown
        pass

    def setEditable(self, *args, **kwargs):  # real signature unknown
        pass

    def setEncoding(self, *args, **kwargs):  # real signature unknown
        pass

    def setFixedFont(self, *args, **kwargs):  # real signature unknown
        pass

    def setFontScaleFactor(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setForcePermitLocalImages(self, *args, **kwargs):
        pass

    def setFormNotification(self, *args, **kwargs):  # real signature unknown
        pass

    def setJavaEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def setJScriptEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setJSDefaultStatusBarText(self, *args, **kwargs):
        pass

    def setJSStatusBarText(self, *args, **kwargs):  # real signature unknown
        pass

    def setLocalFilePath(self, *args, **kwargs):  # real signature unknown
        pass

    def setLocalFileTemporary(self, *args, **kwargs):  # real signature unknown
        pass

    def setLocalXMLFile(self, *args, **kwargs):  # real signature unknown
        pass

    def setMetaRefreshEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setOnlyLocalReferences(self, *args, **kwargs):
        pass

    # real signature unknown
    def setPluginInterfaceVersion(self, *args, **kwargs):
        pass

    # real signature unknown
    def setPluginPageQuestionAsked(self, *args, **kwargs):
        pass

    def setPluginsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def setSelection(self, *args, **kwargs):  # real signature unknown
        pass

    def setStandardFont(self, *args, **kwargs):  # real signature unknown
        pass

    def setStatusBarText(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setStatusMessagesEnabled(self, *args, **kwargs):
        pass

    # real signature unknown
    def setSuppressedPopupIndicator(self, *args, **kwargs):
        pass

    def settings(self, *args, **kwargs):  # real signature unknown
        pass

    def setUrl(self, *args, **kwargs):  # real signature unknown
        pass

    def setURLCursor(self, *args, **kwargs):  # real signature unknown
        pass

    def setUserStyleSheet(self, *args, **kwargs):  # real signature unknown
        pass

    def setWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def setXML(self, *args, **kwargs):  # real signature unknown
        pass

    def setXMLFile(self, *args, **kwargs):  # real signature unknown
        pass

    def setZoomFactor(self, *args, **kwargs):  # real signature unknown
        pass

    def show(self, *args, **kwargs):  # real signature unknown
        pass

    def showError(self, *args, **kwargs):  # real signature unknown
        pass

    def slotFinished(self, *args, **kwargs):  # real signature unknown
        pass

    def slotWidgetDestroyed(self, *args, **kwargs):  # real signature unknown
        pass

    def startingJob(self, *args, **kwargs):  # real signature unknown
        pass

    def stateChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def statusMessagesEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def stopAnimations(self, *args, **kwargs):  # real signature unknown
        pass

    def submitFormProxy(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def toplevelURL(self, *args, **kwargs):  # real signature unknown
        pass

    def updateZoomFactor(self, *args, **kwargs):  # real signature unknown
        pass

    def urlCursor(self, *args, **kwargs):  # real signature unknown
        pass

    def urlSelected(self, *args, **kwargs):  # real signature unknown
        pass

    def view(self, *args, **kwargs):  # real signature unknown
        pass

    def write(self, *args, **kwargs):  # real signature unknown
        pass

    def zoomFactor(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    Before = 1
    BrowserViewGUI = 1
    CaretBlink = 2
    CaretInvisible = 1
    CaretVisible = 0
    DefaultGUI = 0
    DNSPrefetchDisabled = 0
    DNSPrefetchEnabled = 1
    DNSPrefetchOnlyWWWAndSLD = 2
    Encrypted = 1
    FindLinksOnly = 65536
    FindNoPopups = 131072
    Mixed = 2
    NoNotification = 0
    NotCrypted = 0
    Only = 2
    Unused = 255


class KHTMLSettings():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def accessKeysEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def addAdFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def adFilteredBy(self, *args, **kwargs):  # real signature unknown
        pass

    def adviceToStr(self, *args, **kwargs):  # real signature unknown
        pass

    def allowTabulation(self, *args, **kwargs):  # real signature unknown
        pass

    def autoLoadImages(self, *args, **kwargs):  # real signature unknown
        pass

    def autoSpellCheck(self, *args, **kwargs):  # real signature unknown
        pass

    def availableFamilies(self, *args, **kwargs):  # real signature unknown
        pass

    def baseColor(self, *args, **kwargs):  # real signature unknown
        pass

    def changeCursor(self, *args, **kwargs):  # real signature unknown
        pass

    def cursiveFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def dnsPrefetch(self, *args, **kwargs):  # real signature unknown
        pass

    def encoding(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def fallbackAccessKeysAssignments(self, *args, **kwargs):
        pass

    def fantasyFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def fixedFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def followSystemColors(self, *args, **kwargs):  # real signature unknown
        pass

    def hoverLink(self, *args, **kwargs):  # real signature unknown
        pass

    def init(self, *args, **kwargs):  # real signature unknown
        pass

    def isAdFiltered(self, *args, **kwargs):  # real signature unknown
        pass

    def isAdFilterEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def isAutoDelayedActionsEnabled(self, *args, **kwargs):
        pass

    # real signature unknown
    def isBackRightClickEnabled(self, *args, **kwargs):
        pass

    # real signature unknown
    def isFormCompletionEnabled(self, *args, **kwargs):
        pass

    def isHideAdsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def isJavaEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def isJavaScriptDebugEnabled(self, *args, **kwargs):
        pass

    def isJavaScriptEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def isJavaScriptErrorReportingEnabled(self, *args, **kwargs):
        pass

    # real signature unknown
    def isOpenMiddleClickEnabled(self, *args, **kwargs):
        pass

    def isPluginsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    def jsErrorsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def jsPopupBlockerPassivePopup(self, *args, **kwargs):
        pass

    def KAnimationAdvice(self, *args, **kwargs):  # real signature unknown
        pass

    def KDNSPrefetch(self, *args, **kwargs):  # real signature unknown
        pass

    def KJavaScriptAdvice(self, *args, **kwargs):  # real signature unknown
        pass

    def KJSWindowFocusPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def KJSWindowMovePolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def KJSWindowOpenPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def KJSWindowResizePolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def KJSWindowStatusPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def KSmoothScrollingMode(self, *args, **kwargs):  # real signature unknown
        pass

    def linkColor(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def maxFormCompletionItems(self, *args, **kwargs):
        pass

    def mediumFontSize(self, *args, **kwargs):  # real signature unknown
        pass

    def minFontSize(self, *args, **kwargs):  # real signature unknown
        pass

    def sansSerifFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def serifFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def setFixedFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def setJSErrorsEnabled(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setJSPopupBlockerPassivePopup(self, *args, **kwargs):
        pass

    def setStdFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def settingsToCSS(self, *args, **kwargs):  # real signature unknown
        pass

    def showAnimations(self, *args, **kwargs):  # real signature unknown
        pass

    def smoothScrolling(self, *args, **kwargs):  # real signature unknown
        pass

    def stdFontName(self, *args, **kwargs):  # real signature unknown
        pass

    def strToAdvice(self, *args, **kwargs):  # real signature unknown
        pass

    def textColor(self, *args, **kwargs):  # real signature unknown
        pass

    def underlineLink(self, *args, **kwargs):  # real signature unknown
        pass

    def unfinishedImageFrame(self, *args, **kwargs):  # real signature unknown
        pass

    def userStyleSheet(self, *args, **kwargs):  # real signature unknown
        pass

    def vLinkColor(self, *args, **kwargs):  # real signature unknown
        pass

    def windowFocusPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def windowMovePolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def windowOpenPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def windowResizePolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def windowStatusPolicy(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    KAnimationDisabled = 0
    KAnimationEnabled = 2
    KAnimationLoopOnce = 1
    KDNSPrefetchDisabled = 0
    KDNSPrefetchEnabled = 2
    KDNSPrefetchOnlyWWWAndSLD = 1
    KJavaScriptAccept = 1
    KJavaScriptDunno = 0
    KJavaScriptReject = 2
    KJSWindowFocusAllow = 0
    KJSWindowFocusIgnore = 1
    KJSWindowMoveAllow = 0
    KJSWindowMoveIgnore = 1
    KJSWindowOpenAllow = 0
    KJSWindowOpenAsk = 1
    KJSWindowOpenDeny = 2
    KJSWindowOpenSmart = 3
    KJSWindowResizeAllow = 0
    KJSWindowResizeIgnore = 1
    KJSWindowStatusAllow = 0
    KJSWindowStatusIgnore = 1
    KSmoothScrollingDisabled = 0
    KSmoothScrollingEnabled = 2
    KSmoothScrollingWhenEfficient = 1


class KHTMLView(__PyQt4_QtGui.QScrollArea):
    # no doc

    def actionEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def addChild(self, *args, **kwargs):  # real signature unknown
        pass

    def changeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def childEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def clear(self, *args, **kwargs):  # real signature unknown
        pass

    def cleared(self, *args, **kwargs):  # real signature unknown
        pass

    def closeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def connectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def contentsHeight(self, *args, **kwargs):  # real signature unknown
        pass

    def contentsToViewport(self, *args, **kwargs):  # real signature unknown
        pass

    def contentsWidth(self, *args, **kwargs):  # real signature unknown
        pass

    def contentsX(self, *args, **kwargs):  # real signature unknown
        pass

    def contentsY(self, *args, **kwargs):  # real signature unknown
        pass

    def contextMenuEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def create(self, *args, **kwargs):  # real signature unknown
        pass

    def customEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def destroy(self, *args, **kwargs):  # real signature unknown
        pass

    def disconnectNotify(self, *args, **kwargs):  # real signature unknown
        pass

    def displayAccessKeys(self, *args, **kwargs):  # real signature unknown
        pass

    def doAutoScroll(self, *args, **kwargs):  # real signature unknown
        pass

    def dragEnterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragLeaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def dragMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def drawFrame(self, *args, **kwargs):  # real signature unknown
        pass

    def dropEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def enabledChange(self, *args, **kwargs):  # real signature unknown
        pass

    def enterEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def event(self, *args, **kwargs):  # real signature unknown
        pass

    def eventFilter(self, *args, **kwargs):  # real signature unknown
        pass

    def findAheadActive(self, *args, **kwargs):  # real signature unknown
        pass

    def finishedLayout(self, *args, **kwargs):  # real signature unknown
        pass

    def focusInEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusNextPrevChild(self, *args, **kwargs):  # real signature unknown
        pass

    def focusOutEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def focusPreviousChild(self, *args, **kwargs):  # real signature unknown
        pass

    def fontChange(self, *args, **kwargs):  # real signature unknown
        pass

    def frameWidth(self, *args, **kwargs):  # real signature unknown
        pass

    def hideAccessKeys(self, *args, **kwargs):  # real signature unknown
        pass

    def hideEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def inputMethodEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyPressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def keyReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def languageChange(self, *args, **kwargs):  # real signature unknown
        pass

    def layout(self, *args, **kwargs):  # real signature unknown
        pass

    def leaveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def marginHeight(self, *args, **kwargs):  # real signature unknown
        pass

    def marginWidth(self, *args, **kwargs):  # real signature unknown
        pass

    def metric(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseDoubleClickEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseMoveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mousePressEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def mouseReleaseEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def moveEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paintEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def paletteChange(self, *args, **kwargs):  # real signature unknown
        pass

    def part(self, *args, **kwargs):  # real signature unknown
        pass

    def print_(self, *args, **kwargs):  # real signature unknown
        pass

    def receivers(self, *args, **kwargs):  # real signature unknown
        pass

    def repaintAccessKeys(self, *args, **kwargs):  # real signature unknown
        pass

    def repaintContents(self, *args, **kwargs):  # real signature unknown
        pass

    def resetInputContext(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeContents(self, *args, **kwargs):  # real signature unknown
        pass

    def resizeEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def scrollBy(self, *args, **kwargs):  # real signature unknown
        pass

    def scrollContentsBy(self, *args, **kwargs):  # real signature unknown
        pass

    def sender(self, *args, **kwargs):  # real signature unknown
        pass

    def setContentsPos(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setHorizontalScrollBarPolicy(self, *args, **kwargs):
        pass

    def setMarginHeight(self, *args, **kwargs):  # real signature unknown
        pass

    def setMarginWidth(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setSmoothScrollingMode(self, *args, **kwargs):
        pass

    # real signature unknown
    def setSmoothScrollingModeDefault(self, *args, **kwargs):
        pass

    def setupViewport(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def setVerticalScrollBarPolicy(self, *args, **kwargs):
        pass

    def setViewportMargins(self, *args, **kwargs):  # real signature unknown
        pass

    def setZoomLevel(self, *args, **kwargs):  # real signature unknown
        pass

    def showEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def slotPaletteChanged(self, *args, **kwargs):  # real signature unknown
        pass

    def SmoothScrollingMode(self, *args, **kwargs):  # real signature unknown
        pass

    def smoothScrollingMode(self, *args, **kwargs):  # real signature unknown
        pass

    def tabletEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def timerEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def updateContents(self, *args, **kwargs):  # real signature unknown
        pass

    def updateMicroFocus(self, *args, **kwargs):  # real signature unknown
        pass

    def viewportEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def viewportToContents(self, *args, **kwargs):  # real signature unknown
        pass

    def visibleHeight(self, *args, **kwargs):  # real signature unknown
        pass

    def visibleWidth(self, *args, **kwargs):  # real signature unknown
        pass

    def wheelEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def widgetEvent(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def windowActivationChange(self, *args, **kwargs):
        pass

    def zoomLevel(self, *args, **kwargs):  # real signature unknown
        pass

    def zoomView(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    SSMDisabled = 0
    SSMEnabled = 2
    SSMWhenEfficient = 1
