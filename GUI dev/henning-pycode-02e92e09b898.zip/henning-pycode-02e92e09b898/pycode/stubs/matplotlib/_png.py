# encoding: utf-8
# module matplotlib._png
# from /usr/lib/pymodules/python2.7/matplotlib/_png.so by generator 1.96
""" Module to write PNG files """
# no imports

# functions


def read_png(fileobj):  # real signature unknown; restored from __doc__
    """ read_png(fileobj) """
    pass


# real signature unknown; restored from __doc__
def write_png(buffer, width, height, fileobj, dpi=None):
    """ write_png(buffer, width, height, fileobj, dpi=None) """
    pass


# no classes
