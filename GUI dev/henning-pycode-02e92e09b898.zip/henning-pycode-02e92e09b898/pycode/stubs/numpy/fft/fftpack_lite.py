# encoding: utf-8
# module numpy.fft.fftpack_lite
# from /usr/lib/pymodules/python2.7/numpy/fft/fftpack_lite.so by generator 1.96
# no doc
# no imports

# functions


def cfftb(*args, **kwargs):  # real signature unknown
    """  """
    pass


def cfftf(*args, **kwargs):  # real signature unknown
    """  """
    pass


def cffti(*args, **kwargs):  # real signature unknown
    """  """
    pass


def rfftb(*args, **kwargs):  # real signature unknown
    """  """
    pass


def rfftf(*args, **kwargs):  # real signature unknown
    """  """
    pass


def rffti(*args, **kwargs):  # real signature unknown
    """  """
    pass


# classes

class error(Exception):
    # no doc

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
