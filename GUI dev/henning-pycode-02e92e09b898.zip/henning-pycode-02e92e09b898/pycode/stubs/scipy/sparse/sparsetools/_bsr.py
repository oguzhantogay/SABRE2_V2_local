# encoding: utf-8
# module scipy.sparse.sparsetools._bsr calls itself _bsr
# from /usr/lib/python2.7/dist-packages/scipy/sparse/sparsetools/_bsr.so by generator 1.96
# no doc

# imports
from _bsr import (SWIG_PyInstanceMethod_New, bsr_diagonal, bsr_eldiv_bsr,
                  bsr_elmul_bsr, bsr_matmat_pass2, bsr_matvec, bsr_matvecs, bsr_minus_bsr,
                  bsr_plus_bsr, bsr_scale_columns, bsr_scale_rows, bsr_sort_indices,
                  bsr_transpose)


# no functions
# no classes
