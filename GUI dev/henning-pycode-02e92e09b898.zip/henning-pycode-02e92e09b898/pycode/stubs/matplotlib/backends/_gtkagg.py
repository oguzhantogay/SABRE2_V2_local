# encoding: utf-8
# module matplotlib.backends._gtkagg
# from /usr/lib/pymodules/python2.7/matplotlib/backends/_gtkagg.so by
# generator 1.96
""" The _gtkagg module """
# no imports

# functions


def agg_to_gtk_drawable(*args, **kwargs):  # real signature unknown
    """ Draw to a gtk drawable from a agg buffer. """
    pass


# no classes
