# encoding: utf-8
# module PyKDE4.phonon
# from /usr/lib/python2.7/dist-packages/PyKDE4/phonon.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class Phonon():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def AbstractAudioOutput(self, *args, **kwargs):  # real signature unknown
        pass

    def AbstractMediaStream(self, *args, **kwargs):  # real signature unknown
        pass

    def AbstractVideoOutput(self, *args, **kwargs):  # real signature unknown
        pass

    def AudioCaptureDevice(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def AudioChannelDescription(self, *args, **kwargs):
        pass

    def AudioDataOutput(self, *args, **kwargs):  # real signature unknown
        pass

    def AudioOutput(self, *args, **kwargs):  # real signature unknown
        pass

    def AudioOutputDevice(self, *args, **kwargs):  # real signature unknown
        pass

    def BackendCapabilities(self, *args, **kwargs):  # real signature unknown
        pass

    def Capture(self, *args, **kwargs):  # real signature unknown
        pass

    def CaptureCategory(self, *args, **kwargs):  # real signature unknown
        pass

    def Category(self, *args, **kwargs):  # real signature unknown
        pass

    def categoryToString(self, *args, **kwargs):  # real signature unknown
        pass

    def createPath(self, *args, **kwargs):  # real signature unknown
        pass

    def createPlayer(self, *args, **kwargs):  # real signature unknown
        pass

    def DiscType(self, *args, **kwargs):  # real signature unknown
        pass

    def Effect(self, *args, **kwargs):  # real signature unknown
        pass

    def EffectDescription(self, *args, **kwargs):  # real signature unknown
        pass

    def EffectParameter(self, *args, **kwargs):  # real signature unknown
        pass

    def EffectWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def ErrorType(self, *args, **kwargs):  # real signature unknown
        pass

    def GlobalConfig(self, *args, **kwargs):  # real signature unknown
        pass

    def MediaController(self, *args, **kwargs):  # real signature unknown
        pass

    def MediaNode(self, *args, **kwargs):  # real signature unknown
        pass

    def MediaObject(self, *args, **kwargs):  # real signature unknown
        pass

    def MediaSource(self, *args, **kwargs):  # real signature unknown
        pass

    def MetaData(self, *args, **kwargs):  # real signature unknown
        pass

    def Mrl(self, *args, **kwargs):  # real signature unknown
        pass

    def ObjectDescriptionData(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def ObjectDescriptionModelData(self, *args, **kwargs):
        pass

    def ObjectDescriptionType(self, *args, **kwargs):  # real signature unknown
        pass

    def Path(self, *args, **kwargs):  # real signature unknown
        pass

    def phononVersion(self, *args, **kwargs):  # real signature unknown
        pass

    def PulseSupport(self, *args, **kwargs):  # real signature unknown
        pass

    def qHash(self, *args, **kwargs):  # real signature unknown
        pass

    def registerMetaTypes(self, *args, **kwargs):  # real signature unknown
        pass

    def SeekSlider(self, *args, **kwargs):  # real signature unknown
        pass

    def State(self, *args, **kwargs):  # real signature unknown
        pass

    def StreamInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def SubtitleDescription(self, *args, **kwargs):  # real signature unknown
        pass

    def VideoCaptureDevice(self, *args, **kwargs):  # real signature unknown
        pass

    def VideoPlayer(self, *args, **kwargs):  # real signature unknown
        pass

    def VideoWidget(self, *args, **kwargs):  # real signature unknown
        pass

    def VideoWidgetInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def VolumeFaderEffect(self, *args, **kwargs):  # real signature unknown
        pass

    def VolumeSlider(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    AccessibilityCategory = 5
    AlbumMetaData = 1
    ArtistMetaData = 0
    AudioCaptureDeviceType = 4
    AudioChannelType = 2
    AudioOutputDeviceType = 0
    BufferingState = 3
    Cd = 0
    CommunicationCaptureCategory = 3
    CommunicationCategory = 3
    ControlCaptureCategory = 5
    DateMetaData = 3
    DescriptionMetaData = 6
    Dvd = 1
    EffectType = 1
    ErrorState = 5
    FatalError = 2
    GameCategory = 4
    GenreMetaData = 4
    LastCategory = 5
    LoadingState = 0
    MusicBrainzDiscIdMetaData = 7
    MusicCategory = 1
    NoCaptureCategory = -1
    NoCategory = -1
    NoDisc = -1
    NoError = 0
    NormalError = 1
    NotificationCategory = 0
    PausedState = 4
    PlayingState = 2
    RecordingCaptureCategory = 4
    StoppedState = 1
    SubtitleType = 3
    TitleMetaData = 2
    TracknumberMetaData = 5
    Vcd = 2
    VideoCaptureDeviceType = 5
    VideoCategory = 2
