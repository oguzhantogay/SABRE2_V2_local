# encoding: utf-8
# module PyQt4.QtAssistant
# from /usr/lib/python2.7/dist-packages/PyQt4/QtAssistant.so by generator 1.96
# no doc

# imports
import PyQt4.QtCore as __PyQt4_QtCore


# no functions
# classes

class QAssistantClient(__PyQt4_QtCore.QObject):

    """ QAssistantClient(QString, QObject parent=None) """

    def assistantClosed(self, *args, **kwargs):  # real signature unknown
        """ QAssistantClient.assistantClosed[] [signal] """
        pass

    def assistantOpened(self, *args, **kwargs):  # real signature unknown
        """ QAssistantClient.assistantOpened[] [signal] """
        pass

    def closeAssistant(self):  # real signature unknown; restored from __doc__
        """ QAssistantClient.closeAssistant() """
        pass

    def error(self, *args, **kwargs):  # real signature unknown
        """ QAssistantClient.error[QString] [signal] """
        pass

    def isOpen(self):  # real signature unknown; restored from __doc__
        """ QAssistantClient.isOpen() -> bool """
        return False

    def openAssistant(self):  # real signature unknown; restored from __doc__
        """ QAssistantClient.openAssistant() """
        pass

    # real signature unknown; restored from __doc__
    def setArguments(self, QStringList):
        """ QAssistantClient.setArguments(QStringList) """
        pass

    # real signature unknown; restored from __doc__
    def showPage(self, QString):
        """ QAssistantClient.showPage(QString) """
        pass

    # real signature unknown; restored from __doc__
    def __init__(self, QString, QObject_parent=None):
        pass
