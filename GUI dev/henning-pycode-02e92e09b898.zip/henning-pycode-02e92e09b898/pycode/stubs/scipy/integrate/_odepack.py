# encoding: utf-8
# module scipy.integrate._odepack
# from /usr/lib/python2.7/dist-packages/scipy/integrate/_odepack.so by generator 1.96
# no doc
# no imports

# Variables with simple values

__version__ = ' 1.9 '

# functions

# real signature unknown; NOTE: unreliably restored from __doc__


def odeint(fun, y0, t, args=(), Dfun=None, col_deriv=0, ml, *args, **kwargs):
    """
    [y,{infodict,}istate] = odeint(fun, y0, t, args=(), Dfun=None, col_deriv=0, ml=, mu=, full_output=0, rtol=, atol=, tcrit=, h0=0.0, hmax=0.0, hmin=0.0, ixpr=0.0, mxstep=0.0, mxhnil=0, mxordn=0, mxords=0)
      yprime = fun(y,t,...)
    """
    pass


# no classes
