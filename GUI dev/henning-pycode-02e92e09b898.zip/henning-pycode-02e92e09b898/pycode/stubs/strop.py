#!/usr/bin/env python
# module: 'strop'


def atof(*x):
    return


def atoi(*x):
    return


def atol(*x):
    return


def capitalize(*x):
    return


def count(*x):
    return


def expandtabs(*x):
    return


def find(*x):
    return


def join(*x):
    return


def joinfields(*x):
    return


def lower(*x):
    return

lowercase = ''


def lstrip(*x):
    return


def maketrans(*x):
    return


def replace(*x):
    return


def rfind(*x):
    return


def rstrip(*x):
    return


def split(*x):
    return


def splitfields(*x):
    return


def strip(*x):
    return


def swapcase(*x):
    return


def translate(*x):
    return


def upper(*x):
    return

uppercase = ''
whitespace = ''
