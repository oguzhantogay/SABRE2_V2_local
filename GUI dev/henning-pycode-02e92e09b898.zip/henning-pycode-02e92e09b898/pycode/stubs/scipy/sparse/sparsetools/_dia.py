# encoding: utf-8
# module scipy.sparse.sparsetools._dia calls itself _dia
# from /usr/lib/python2.7/dist-packages/scipy/sparse/sparsetools/_dia.so by generator 1.96
# no doc

# imports
from _dia import SWIG_PyInstanceMethod_New, dia_matvec


# no functions
# no classes
