# encoding: utf-8
# module matplotlib.backends._backend_agg
# from /usr/lib/pymodules/python2.7/matplotlib/backends/_backend_agg.so by
# generator 1.96
""" The agg rendering backend """
# no imports

# functions

# real signature unknown; restored from __doc__


def RendererAgg(width, height, dpi):
    """ RendererAgg(width, height, dpi) """
    pass


# no classes
