# encoding: utf-8
# module scipy.sparse.sparsetools._coo calls itself _coo
# from /usr/lib/python2.7/dist-packages/scipy/sparse/sparsetools/_coo.so by generator 1.96
# no doc

# imports
from _coo import (SWIG_PyInstanceMethod_New, coo_count_diagonals, coo_matvec,
                  coo_tocsc, coo_tocsr, coo_todense)


# no functions
# no classes
