# encoding: utf-8
# module PyKDE4.kparts
# from /usr/lib/python2.7/dist-packages/PyKDE4/kparts.so by generator 1.96
# no doc
# no imports

# functions


def qSwap(*args, **kwargs):  # real signature unknown
    pass


# classes

class KParts():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def BrowserArguments(self, *args, **kwargs):  # real signature unknown
        pass

    def BrowserExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def BrowserHostExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def BrowserInterface(self, *args, **kwargs):  # real signature unknown
        pass

    # real signature unknown
    def BrowserOpenOrSaveQuestion(self, *args, **kwargs):
        pass

    def BrowserRun(self, *args, **kwargs):  # real signature unknown
        pass

    def Event(self, *args, **kwargs):  # real signature unknown
        pass

    def Factory(self, *args, **kwargs):  # real signature unknown
        pass

    def FileInfoExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def GUIActivateEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def HistoryProvider(self, *args, **kwargs):  # real signature unknown
        pass

    def HtmlExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def LiveConnectExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def MainWindow(self, *args, **kwargs):  # real signature unknown
        pass

    def OpenUrlArguments(self, *args, **kwargs):  # real signature unknown
        pass

    def OpenUrlEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def Part(self, *args, **kwargs):  # real signature unknown
        pass

    def PartActivateEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def PartBase(self, *args, **kwargs):  # real signature unknown
        pass

    def PartManager(self, *args, **kwargs):  # real signature unknown
        pass

    def PartSelectEvent(self, *args, **kwargs):  # real signature unknown
        pass

    def Plugin(self, *args, **kwargs):  # real signature unknown
        pass

    def ReadOnlyPart(self, *args, **kwargs):  # real signature unknown
        pass

    def ReadWritePart(self, *args, **kwargs):  # real signature unknown
        pass

    def ScriptableExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def SelectorInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def StatusBarExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def TextExtension(self, *args, **kwargs):  # real signature unknown
        pass

    def WindowArgs(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default
