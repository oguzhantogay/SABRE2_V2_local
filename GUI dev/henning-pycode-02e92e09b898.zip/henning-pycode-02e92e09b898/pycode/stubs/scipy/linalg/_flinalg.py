# encoding: utf-8
# module scipy.linalg._flinalg
# from /usr/lib/python2.7/dist-packages/scipy/linalg/_flinalg.so by
# generator 1.96
"""
This module '_flinalg' is auto-generated with f2py (version:1).
Functions:
  det,info = ddet_c(a,overwrite_a=0)
  det,info = ddet_r(a,overwrite_a=0)
  det,info = sdet_c(a,overwrite_a=0)
  det,info = sdet_r(a,overwrite_a=0)
  det,info = zdet_c(a,overwrite_a=0)
  det,info = zdet_r(a,overwrite_a=0)
  det,info = cdet_c(a,overwrite_a=0)
  det,info = cdet_r(a,overwrite_a=0)
  p,l,u,info = dlu_c(a,permute_l=0,overwrite_a=0)
  p,l,u,info = zlu_c(a,permute_l=0,overwrite_a=0)
  p,l,u,info = slu_c(a,permute_l=0,overwrite_a=0)
  p,l,u,info = clu_c(a,permute_l=0,overwrite_a=0)
.
"""
# no imports

# Variables with simple values

__version__ = '$Revision: $'

# no functions
# no classes
# variables with complex values

cdet_c = None  # (!) real value is ''

cdet_r = None  # (!) real value is ''

clu_c = None  # (!) real value is ''

ddet_c = None  # (!) real value is ''

ddet_r = None  # (!) real value is ''

dlu_c = None  # (!) real value is ''

sdet_c = None  # (!) real value is ''

sdet_r = None  # (!) real value is ''

slu_c = None  # (!) real value is ''

zdet_c = None  # (!) real value is ''

zdet_r = None  # (!) real value is ''

zlu_c = None  # (!) real value is ''
