# -*- coding: utf-8 -*-
# Best of
# http://code.google.com/p/spyderlib/source/browse/spyderlib/rope_patch.py
# http://code.google.com/p/spyderlib/source/browse/spyderlib/widgets/sourcecode/codeeditor.py
# http://code.google.com/p/spyderlib/source/browse/spyderlib/utils/codeanalysis.py
# http://code.google.com/p/spyderlib/source/browse/spyderlib/utils/module_completion.py
# (Copyright © 2011 Pierre Raybaut, Licensed under the terms of the MIT License)
