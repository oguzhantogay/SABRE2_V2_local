import peewee


AISC_database = np.array()

print(AISC_database[0,1])
