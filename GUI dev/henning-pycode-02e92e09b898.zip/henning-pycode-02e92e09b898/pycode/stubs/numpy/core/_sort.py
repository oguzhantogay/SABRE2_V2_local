# encoding: utf-8
# module numpy.core._sort
# from /usr/lib/pymodules/python2.7/numpy/core/_sort.so by generator 1.96
# no doc
# no imports

# no functions
# no classes
