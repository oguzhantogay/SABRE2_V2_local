# encoding: utf-8
# module PyKDE4.solid
# from /usr/lib/python2.7/dist-packages/PyKDE4/solid.so by generator 1.96
# no doc
# no imports

# no functions
# classes


class Solid():  # skipped bases: <type 'sip.wrapper'>
    # no doc

    def AcAdapter(self, *args, **kwargs):  # real signature unknown
        pass

    def AudioInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def Battery(self, *args, **kwargs):  # real signature unknown
        pass

    def Block(self, *args, **kwargs):  # real signature unknown
        pass

    def Button(self, *args, **kwargs):  # real signature unknown
        pass

    def Camera(self, *args, **kwargs):  # real signature unknown
        pass

    def Device(self, *args, **kwargs):  # real signature unknown
        pass

    def DeviceInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def DeviceNotifier(self, *args, **kwargs):  # real signature unknown
        pass

    def DvbInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def ErrorType(self, *args, **kwargs):  # real signature unknown
        pass

    def GenericInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def InternetGateway(self, *args, **kwargs):  # real signature unknown
        pass

    def Networking(self, *args, **kwargs):  # real signature unknown
        pass

    def NetworkInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def NetworkShare(self, *args, **kwargs):  # real signature unknown
        pass

    def OpticalDisc(self, *args, **kwargs):  # real signature unknown
        pass

    def OpticalDrive(self, *args, **kwargs):  # real signature unknown
        pass

    def PortableMediaPlayer(self, *args, **kwargs):  # real signature unknown
        pass

    def PowerManagement(self, *args, **kwargs):  # real signature unknown
        pass

    def Predicate(self, *args, **kwargs):  # real signature unknown
        pass

    def Processor(self, *args, **kwargs):  # real signature unknown
        pass

    def SerialInterface(self, *args, **kwargs):  # real signature unknown
        pass

    def SmartCardReader(self, *args, **kwargs):  # real signature unknown
        pass

    def StorageAccess(self, *args, **kwargs):  # real signature unknown
        pass

    def StorageDrive(self, *args, **kwargs):  # real signature unknown
        pass

    def StorageVolume(self, *args, **kwargs):  # real signature unknown
        pass

    def Video(self, *args, **kwargs):  # real signature unknown
        pass

    def __init__(self, *args, **kwargs):  # real signature unknown
        pass

    __weakref__ = property(lambda self: object())  # default

    DeviceBusy = 2
    InvalidOption = 5
    MissingDriver = 6
    NoError = 0
    OperationFailed = 3
    UnauthorizedOperation = 1
    UserCanceled = 4
